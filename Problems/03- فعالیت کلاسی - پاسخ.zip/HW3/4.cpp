#include<iostream>
using namespace std;
int main()
{
    int n,s;
    cin>>n;
    for(int i=1,j=1 ; i<=n ; i++)
    {
        if(j==n+1)
        {
            break;
        }
        s+=i;
        if(i==j)
        {
            i=0;
            j++;
        }
    }
    cout<<s<<endl;
    system("pause");
}