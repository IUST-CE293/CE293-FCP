#include <iostream>
using namespace std;
int main()
{
    int m,n,kmm4,bmm3;
    cin>>m>>n;
    for(int i=1,counter=1 ; counter<=4 ; i++)
    {
        if((m*i)%n==0)
        {
            counter++;
            kmm4=m*i;
        }
    }
    cout<<kmm4<<endl;
    int counter=1;
    for(int i=1 ; counter<=3 ; i++)
    {
        if(m%i==0 && n%i==0)
        {
            counter++;
            bmm3=i;
        }
    }
    if(counter==4)
    {
        cout<<bmm3;
    }
    else
    {
        cout<<"-1";
    }
    return 0;
}