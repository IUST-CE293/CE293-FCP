#include<iostream>
#include<cmath>
using namespace std;
int main()
{
    int n,i=0,odd=0,even=0;
    cin>>n;
    while(n!=0)
    {
        if((n%10)%2==0)
        {
            even+=(n%10)*pow(10,i);
            i++;
        }
        else
        {
            odd=((odd*10)+n%10);
        }
        n/=10;
    }
    bool prime=true;
    n=fabs(even-odd);
    if(n==1)
    {
        prime=false;
    }
    for(i=2 ; i<n ; i++)
    {
        if(n%i==0)
        {
            prime=false;
        }
    }
    if(prime)
    {
        cout<<"prime";
    }
    else
    {
        cout<<"not prime";
    }
}