#include<iostream>
using namespace std;
int isprime(int i , int x=2)
{
    if(i==x)
    {
        return i;
    }
    else if(i%x!=0)
    {
        return isprime(i,x+1);
    }
    else
    {
        return 0;
    }
}
int main()
{
    int n,a1=1,a2=1,a3,sum,s=0,j=2,x=2;
    cin>>n;
    for(int i=1 ; i<=n-2 ; i++)
    {
        a3=a1+a2;
        a1=a2;
        a2=a3;
    }
    for(int i=2 ; i<a3 ; i++)
    {
        sum+=isprime(i,x);
        x=2;
    }
    while(sum!=0)
    {
        s+=sum%10;
        sum/=10;
    }
    bool prime=true;
    for(int j=2 ; j<s ; j++)
        {
            if(s%j==0)
            {
                prime=false;
                break;
            }
        }
    if(prime)
    {
        cout<<"Yes";
    }
    else
    {
        cout<<"No";
    }
    return 0;
}