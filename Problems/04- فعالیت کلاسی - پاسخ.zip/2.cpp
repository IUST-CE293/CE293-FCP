#include<iostream>
using namespace std;
int sum(int a)
{
    int sum=0;
    while(a!=0)
    {
        sum+=a%10;
        a/=10;
    }
    return sum;
}
int main()
{
    int m,n,p;
    cin>>m>>n>>p;
    for(int i=min(m,n) ; i<max(m,n) ; i++)
    {
        if(sum(i)==p)
        {
            cout<<i<<" ";
        }
    }
}