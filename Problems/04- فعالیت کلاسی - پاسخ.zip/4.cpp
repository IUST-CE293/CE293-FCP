#include<iostream>
using namespace std;
int main()
{
    int n;
    cin>>n;
    int A[n][n];
    for(int i=0 ; i<n ; i++)
    {
        for(int j=0 ; j<n ; j++)
        {
            cin>>A[i][j];
        }
    }
    bool bm=false;
    bool pm=false;
    bool h=true;
    for(int i=0 ; i<n ; i++)
    {
        for(int j=0 ; j<n ; j++)
        {
            if(j-i>0 && A[i][j]!=0)
            {
                bm=true;
            }
            else if(i-j>0 && A[i][j]!=0)
            {
                pm=true;
            }
            else if(i==j && A[i][j]!=1)
            {
                h=false;
            }
            
        }
    }
    if(!bm && !pm)
    {
        if(h)
        {
            cout<<"hamani";
        }
        else
        {
            cout<<"ghotri";
        }
    }
    else if(bm)
    {
        cout<<"balamosalasi";
    }
    else if(pm)
    {
        cout<<"payinmosalasi";
    }
    else
    {
        cout<<"namoshakhas";
    }
}