#include<iostream>
using namespace std;
int main()
{
    int n,a1,a2;
    cin>>n;
    for(int i=3 ; i<=n-2 ; i++)
    {
        bool prime1=true;
        bool prime2=true;
        for(int j=2 ; j<i ; j++)
        {
            if(i%j==0)
            {
                prime1=false;
            }
        }
        if(prime1)
        {
            for(int j=2 ; j<i+2 ; j++)
            {
                if((i+2)%j==0)
                {
                    prime2=false;
                }
            }
            if(prime2)
            {
                cout<<"("<<i<<" - "<<i+2<<") ";
            }
        }
    }

}