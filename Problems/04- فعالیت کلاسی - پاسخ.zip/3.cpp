#include<iostream>
#include<cmath>
using namespace std;
int main()
{
    int n,sum,t,i1,i2,i3;
    cin>>n;
    int n_copy=n;
    for(int i=1 ; i<=n ; i++)
    {
        t=0;
        i1=i;
        i2=i;
        i3=i;
        sum=0;
        while(i1!=0)
        {
            t++;
            i1/=10;
        }
        while(i2!=0)
        {
            sum+=pow((i2%10) , t);
            i2/=10;
        }
        if(sum==i3)
        {
            cout<<i3<<" ";
        }
    }
}