#include <iostream>
using namespace std;

bool is_sub(int n,int m,int arr[],int sub[])
{
    bool found = false;
    for(int i=0;i<m;i++)
    {
        found = false;
        for(int j=0;j<n;j++)
        {
            if(sub[i]==arr[j])
            {
                found = true;
                break;
            }
        }
        if(!found)
            return false;
    }
    return true;
}

int main()
{
    int n,m;
    cin >> n >> m;
    int arr[n];
    int sub[m];
    for(int i=0;i<n+m;i++)
    {
        if(i<n)
            cin >> arr[i];
        else
            cin >> sub[i-n];
    }  
    cout << is_sub(n,m,arr,sub) << endl;
    return 0;
}