#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main2()
{
    // vector<int> arr;
    // int* arr = new int[100000000];
    // delete[] arr;
    // cout << arr[776673] << endl;
    // cout << 
    // int x = 6;
    // long long arr[100000000];
    // int arr[5] = {1,2,3,4,5};
    // int arr_2[8];
    // cout << max({5,2,65}) << endl;
    // cout << *(arr+4) << endl;
    // int arr_2[] = {1,2,4};
    // cout << arr[3] << endl;
    return 0;
}
bool sub_arr(int n,int m,int arr[],int sub[])
{
    bool found = false;
    for(int i=0;i<m;i++)
    {
        found = false;
        for(int j=0;j<n;j++)
        {
            if(sub[i]==arr[j])
            {
                found = true;
                break;
            }
        }
        if(!found)
        {
            return false;
        }
    }
    return true;
}
int main()
{
    int n,m;
    cin >> n >> m;
    int arr[n];
    int sub[m];
    for(int i=0;i<n+m;i++)
    {
        if(i<n)
            cin >> arr[i];
        else
            cin >> sub[i-n];
    }
    cout << sub_arr(n,m,arr,sub) << endl;

    // for(int i=0;i<n;i++)
    // {
    //     cout << arr[i] << ' ';
    // }
    // 1 4 6 -7 4
    // 1 6 4

    return 0;
}