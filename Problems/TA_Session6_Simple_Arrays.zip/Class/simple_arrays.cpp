#include <iostream>
using namespace std;

void func1(int arr[])
{
    cout << arr[0] << endl;
}

void func2(int* arr)
{
    cout << arr[1] << endl;
}

void func3(int arr[3])
{
    cout << arr[2] << endl;
}

int main()
{
    // int arr[4] = {}; //0,0,0,0
    // cout << arr[0] << endl<< arr[2]<< endl << arr[3]<< endl;

    // int arr[]; //need size

    // int* arr = new int[4];
    // delete[] arr;

    // int arr[] = {1,2,3,4,5};
    // cout << sizeof(arr) << endl;
    // cout << sizeof(int) << endl;
    // cout << sizeof(arr)/sizeof(int) << endl;
    // int len = sizeof(arr)/sizeof(int);
    // for(int i=0;i<len;i++)
    // {
    //     cout << arr[i] << endl;
    // }
    // arr[i] = 1; //Give Value

    // int arr[] = {1,2,3,4};
    // func1(arr);
    // func2(arr);
    // func3(arr);

    // int arr[] = {7,2,4,5};
    // cout << arr[6] << endl;
    // cout << arr[-2] << endl;

    // int arr[] = {1,2,4,3.3};
    // cout << arr[3] << endl;

    
    return 0;
}

