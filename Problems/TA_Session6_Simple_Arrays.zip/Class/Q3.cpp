#include <iostream>
using namespace std;

int main()
{
    int arr[5] = {2,4,6,8,10};
    int len = sizeof(arr)/sizeof(arr[0]);
    int arr_rev[len];
    for(int i=0;i<len;i++)
    {
        arr_rev[i] = arr[len-i-1];
    }
    for(int i=0;i<len;i++)
    {
        cout << arr_rev[i] << ' ';
    }
    cout << endl;
    
}
