#include<iostream>
#include<string>
using namespace std;

int main()
{
   string u;
   int p;
   cout<<"Enter username: ";
   cin>>u;
   cout<<"Enter password: ";
   cin>>p;
   if(u!="admin")
   cout<<"Username is incorrect";
   if(p!=1234)
   cout<<"Password is incorrect";
   return 0;
}