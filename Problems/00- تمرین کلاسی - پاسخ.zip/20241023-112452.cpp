#include<iostream>
using namespace std;

int main()
{
   int y;
   cout<<"Enter year: ";
   cin>>y;
   if(y%4==3)
   cout<<"This year is a leap year";
   else 
   cout<<"This year is not a leap year";
   return 0;
}