#include<iostream>
using namespace std;

int main()
{
   float a,b,c;
   cout<<"Enter the numbers"<<endl<<"first: ";
   cin>>a;
   cout<<"second: "; cin>>b;
   cout<<"third: "; cin>>c;
   if(a==b&b==c)
   cout<<"The triangle is equilateral";
   else if(a!=b&b!=c&a!=c)
   cout<<"The triangle is different sided";
   else
   cout<<"The triangle is isosceles";
   return 0;
}