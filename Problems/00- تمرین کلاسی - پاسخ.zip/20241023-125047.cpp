#include<iostream>
using namespace std;

int main()
{
   float p,f;
   cout<<"Enter the price: ";
   cin>>p;
   if(p>100)
   f=p*0.9;
   else f=p;
   cout<<"Final price is "<<f;
   return 0;
}