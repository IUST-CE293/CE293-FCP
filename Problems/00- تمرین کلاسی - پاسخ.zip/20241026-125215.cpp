#include<iostream>
#include<string>
using namespace std;

int main()
{
   float a,b,c,m;
   cout<<"Enter scores: ";
   cin>>a>>b>>c;
   m=(a+b+c)/3;
   if(m>=17)
   cout<<"GREAT";
   else if(m>=12&m<17)
   cout<<"Accepted";
   else 
   cout<<"failed";
}