#include<iostream>
using namespace std;

int main()
{
float a,b,c;
cout<<"Enter three numbers:";
cin>>a>>b>>c;
if (a==b or a==c or b==c)
{
cout<<"Error, enter different numbers";
return 0;
}
if(a>b)
{
if(a>c)cout<<a<<" is the biggest number";
 else cout<<c<<" is the biggest number";
}
else if (b>a)
{
if(b>c)cout<<b<<" is the biggest number";
 else cout<<c<<" is the biggest number";
}
return 0;
}