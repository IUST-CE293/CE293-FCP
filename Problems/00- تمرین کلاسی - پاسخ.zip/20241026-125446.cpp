#include<iostream>
using namespace std;

int main()
{
   float a;
   cout<<"Please enter your score: ";
   cin>>a;
   if(a>=90&a<=100)
   cout<<"you're grade A";
   else if(80<=a&a<90)
   cout<<"you're grade B";
   else if(70<=a&a<80)
   cout<<"you're grade C";
   else if(60<=a&a<70)
   cout<<"you're grade D"; 
   else
   cout<<"you're failed";
   return 0;
}