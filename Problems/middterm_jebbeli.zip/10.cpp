#include <iostream>
using namespace std;

// c(5,2) ==> 5!/(2!*(5-2)!)

int factorial(int n) 
{
    if (n == 0 || n == 1) 
    {
        return 1;
    }
    return n * factorial(n - 1);
}


int combinations(int n, int k) 
{
    
    return factorial(n) / (factorial(k) * factorial(n - k));
}

int main() 
{
    int n, k;
    cout << "Enter n (size of the set): ";
    cin >> n;
    cout << "Enter k (number of elements to choose): ";
    cin >> k;

    cout << "The number of combinations C(" << n << ", " << k << ") is: " << combinations(n, k) << endl;

    return 0;
}
