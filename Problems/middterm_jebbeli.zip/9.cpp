#include <iostream>
using namespace std;


bool isPrime(int n, int i = 2)  // 12345
{
    
    if (n <= 1) 
    {
        return false;
    }
    
    if (n < i * i) 
    {
        return true;
    }
    
    if (n % i == 0) 
    {
        return false;
    }
    
    return isPrime(n, i + 1);
}

int main() 
{
    int num;
    cin >> num;

    if (isPrime(num)) 
    {
        cout << num << " is prime." << endl;
    }
     else 
    {
        cout << num << " is not prime." << endl;
    }

    return 0;
}
