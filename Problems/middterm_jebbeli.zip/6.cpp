// اجتماع دو مجموعه

#include <iostream>
using namespace std;

// تابع برای محاسبه اجتماع دو مجموعه
void unionOfSets(int a1, int a2, int a3, int a4, int a5, int b1, int b2, int b3, int b4, int b5) 
{
    cout << "Union: ";
    
    // اضافه کردن اعضای مجموعه اول
    cout << a1 << " " << a2 << " " << a3 << " " << a4 << " " << a5 << " ";
    // اضافه کردن اعضای مجموعه دوم که در مجموعه اول نیست
    if (b1 != a1 && b1 != a2 && b1 != a3 && b1 != a4 && b1 != a5) cout << b1 << " ";
    if (b2 != a1 && b2 != a2 && b2 != a3 && b2 != a4 && b2 != a5) cout << b2 << " ";
    if (b3 != a1 && b3 != a2 && b3 != a3 && b3 != a4 && b3 != a5) cout << b3 << " ";
    if (b4 != a1 && b4 != a2 && b4 != a3 && b4 != a4 && b4 != a5) cout << b4 << " ";
    if (b5 != a1 && b5 != a2 && b5 != a3 && b5 != a4 && b5 != a5) cout << b5 << " ";

    cout << endl;
}

int main() 
{
    int a1, a2, a3, a4, a5;
    int b1, b2, b3, b4, b5;

    cin >> a1 >> a2 >> a3 >> a4 >> a5;

    cin >> b1 >> b2 >> b3 >> b4 >> b5;

    unionOfSets(a1, a2, a3, a4, a5, b1, b2, b3, b4, b5);
    return 0;
}
