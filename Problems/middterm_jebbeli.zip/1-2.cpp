#include <iostream>
using namespace std;

int main() 
{
    int voterCount; // تعداد کل رای‌دهندگان
    cin >> voterCount;

    int vote; // متغیر برای نگهداری رای فعلی
    int candidate1 = 0, candidate2 = 0, candidate3 = 0, candidate4 = 0, candidate5 = 0; // شمارنده آرا برای هر کاندیدا

    // دریافت آرای رای‌دهندگان و شمارش آرا
    for (int i = 0; i < voterCount; i++) 
    {
        cin >> vote;
        if (vote == 1) candidate1++;
        else if (vote == 2) candidate2++;
        else if (vote == 3) candidate3++;
        else if (vote == 4) candidate4++;
        else if (vote == 5) candidate5++;
    }

    int majorityThreshold = (voterCount / 2) + 1; // حداقل تعداد آرای لازم برای اکثریت
    int selectedCandidate = 0; // کاندیدای منتخب

    // بررسی شرایط انتخاب شدن کاندیدا
    if (candidate1 >= majorityThreshold) selectedCandidate = 1;
    else if (candidate2 >= majorityThreshold) selectedCandidate = 2;
    else if (candidate3 >= majorityThreshold) selectedCandidate = 3;
    else if (candidate4 >= majorityThreshold) selectedCandidate = 4;
    else if (candidate5 >= majorityThreshold) selectedCandidate = 5;

    cout << selectedCandidate; // چاپ شماره کاندیدای منتخب یا 0 در صورت عدم وجود برنده

    return 0;
}
