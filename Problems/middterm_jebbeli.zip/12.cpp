#include <iostream>
using namespace std;

int sum = 0;
int func1(int number){ // 123
    
    if (number <= 0){
        return sum;
    }
    sum += number % 10; // 3, 5, 6
    // number /= 10;
    return func1(number/10);
}

int main(){
    int number;
    cin >> number;
    
    cout << func1(number);
}

