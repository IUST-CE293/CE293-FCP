#include <iostream>
using namespace std;

// تابع محاسبه ب.م.م (بزرگ‌ترین مقسوم‌علیه مشترک) با الگوریتم اقلیدس
int gcd(int x, int y) 
{
    if (y == 0)
        return x;
    return gcd(y, x % y);
}

// تابع محاسبه ک.م.م (کوچک‌ترین مضرب مشترک)
int lcm(int x, int y) 
{
    return (x * y) / gcd(x, y);
}

int main() 
{
    int numerator1, denominator1; // صورت و مخرج کسر اول
    int numerator2, denominator2; // صورت و مخرج کسر دوم
    int commonDenominator; // مخرج مشترک
    int numeratorSum; // مجموع صورت کسرها

    // دریافت مقادیر صورت و مخرج دو کسر
    cin >> numerator1 >> denominator1;
    cin >> numerator2 >> denominator2;

    // محاسبه مخرج مشترک
    commonDenominator = lcm(denominator1, denominator2);

    // محاسبه مجموع صورت کسرها با استفاده از مخرج مشترک
    numeratorSum = numerator1 * (commonDenominator / denominator1) +
                   numerator2 * (commonDenominator / denominator2);

    // چاپ صورت و مخرج کسر جدید
    cout << numeratorSum << " " << commonDenominator;

    return 0;
}
