#include <iostream>
using namespace std;

// تابع محاسبه ب.م.م (بزرگ‌ترین مقسوم‌علیه مشترک) با استفاده از الگوریتم اقلیدس
int b_m_m(int x, int y) 
{
    if (y == 0)
        return x;
    return b_m_m(y, x % y); // بازگشت مقدار محاسبه‌شده
}

// تابع محاسبه ک.م.م (کوچک‌ترین مضرب مشترک)
int k_m_m(int x, int y) 
{
    return (x * y) / b_m_m(x, y);
}

int main() 
{
    int a[4]; // آرایه‌ای برای نگهداری ورودی‌ها (صورت و مخرج کسرها)
    int commonDenominator; // مخرج مشترک
    int numeratorSum = 0; // مجموع صورت کسرها

    // دریافت مقادیر ورودی
    for (int i = 0; i < 4; i++) 
    {
        cin >> a[i];
    }

    // محاسبه مخرج مشترک
    commonDenominator = k_m_m(a[1], a[3]);

    // محاسبه مجموع صورت کسرها
    numeratorSum = a[0] * (commonDenominator / a[1]) +
                   a[2] * (commonDenominator / a[3]);

    // چاپ صورت و مخرج کسر جدید
    cout << numeratorSum << " " << commonDenominator;

    return 0;
}
