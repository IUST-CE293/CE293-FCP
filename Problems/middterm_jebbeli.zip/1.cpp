#include <iostream>
using namespace std;

int main() 
{
    int voterCount; // تعداد کل رای‌دهندگان
    cin >> voterCount;

    int vote; // متغیر برای نگهداری رای فعلی
    int voteCount[5] = {0}; // آرایه‌ای برای شمارش تعداد آرا برای هر کاندیدا (کاندیداها: 1 تا 5)

    // خواندن آرای رای‌دهندگان
    for (int i = 0; i < voterCount; i++) 
	{
        cin >> vote; 
        voteCount[vote - 1]++; // افزایش تعداد رای کاندیدای مربوطه
    }

    int maxVotes = 0; // بیشترین تعداد آرا
    int selectedCandidate = 0; // کاندیدای منتخب

    // پیدا کردن کاندیدایی که بیشترین رای را دریافت کرده است
    for (int i = 0; i < 5; i++) 
	{
        if (voteCount[i] > maxVotes) 
		{
            maxVotes = voteCount[i];
            selectedCandidate = i + 1; // شماره کاندیدا (1 تا 5)
        }
    }

    // بررسی شرایط انتخاب شدن کاندیدا (حداقل 50 درصد آرا + 1)
    if (maxVotes >= (voterCount / 2) + 1) 
	{
        cout << selectedCandidate; // چاپ شماره کاندیدای منتخب
    } 
	else 
	{
        cout << 0; // چاپ 0 در صورتی که هیچ‌کاندیدایی شرایط را نداشته باشد
    }

    return 0;
}
