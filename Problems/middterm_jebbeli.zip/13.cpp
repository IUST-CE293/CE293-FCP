#include <iostream>
using namespace std;

int a0 = 5;
int q = 3;
int n = 4;
int func1(int a0, int q, int number){ // n=5
    if(number <= 0){
        return a0;
    }
    cout << a0 << ' ';
    return func1(q*a0, q, number - 1);
}
int main(){
// a0 = 5, q=3, n=4
// 5, 15, 45, 135
func1(a0, q, n);
}