#include <iostream>
using namespace std;


int countDivisible(int n, int current = 1) // (17, 1), (17, 2), (17, 3)
{
    
    if (current >= n) 
    {
        return 0;
    }
    
    
    if (current % 3 == 0 || current % 5 == 0) 
    {
        return 1 + countDivisible(n, current + 1); // 1 + 1 + 1 + 1 .. + 1
    }
    
    
    return countDivisible(n, current + 1);
}

int main() 
{
    int n;
    cin >> n;
    
    int result = countDivisible(n);
    cout << result << endl;
    
    return 0;
}
