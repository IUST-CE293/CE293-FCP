#include <iostream>
using namespace std;

int main() 
{
    int n;
    cin >> n;

    // n = 3
    // رسم نیمه بالایی لوزی
    for (int i = 1; i <= n; i++) 
    {
        // چاپ فاصله‌های خالی
        for (int j = 1; j <= n - i; j++) 
        {
            cout << " "; // 2s, 1s, 0s
        }
        // چاپ اعداد افزایشی
        for (int j = 1; j <= i; j++) 
        {
            cout << j; // 1, 12, 123
        }
        // چاپ اعداد کاهشی
        for (int j = i - 1; j >= 1; j--) 
        {
            cout << j; // , 1, 21
        }
        cout << endl;
    }

    // رسم نیمه پایینی لوزی
    for (int i = n - 1; i >= 1; i--) 
    {
        // چاپ فاصله‌های خالی
        for (int j = 1; j <= n - i; j++) 
        {
            cout << " ";
        }
        // چاپ اعداد افزایشی
        for (int j = 1; j <= i; j++) 
        {
            cout << j; //12
        }
        // چاپ اعداد کاهشی
        for (int j = i - 1; j >= 1; j--) 
        {
            cout << j; //1
        }
        cout << endl;
    }

    return 0;
}
