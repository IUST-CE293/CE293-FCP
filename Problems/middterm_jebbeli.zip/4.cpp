#include <iostream>
using namespace std;

int main() 
{
    int day, month; // روز و ماه دریافت وام
    cin >> day >> month;

    day += 100; // اضافه کردن 100 روز به روز دریافت وام

    // محاسبه ماه‌ها و تعداد روزهای آن‌ها
    while (day > 29 && month == 12) // 103, 74
    {
     // ماه اسفند (29 روزه)
        day -= 29;
        month++;
    }
    while (day > 31 && month >= 1 && month <= 6) // 45, 16
    {
     // ماه‌های نیمه اول سال (31 روزه)
        day -= 31;
        month++;
    }
    while (day > 30 && month >= 7 && month <= 11) 
    {
     // ماه‌های نیمه دوم سال (30 روزه)
        day -= 30;
        month++;
    }

    // اصلاح ماه در صورت بیشتر شدن از 12
    if (month > 12) 
    {
        month -= 12;
    }

    // چاپ تاریخ تسویه
    cout << day << " " << month;

    return 0;
}
