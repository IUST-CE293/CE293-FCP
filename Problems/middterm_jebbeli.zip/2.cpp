#include <iostream>
using namespace std;

int main() 
{
    int rows; // تعداد سطرها برای مثلث
    cin >> rows;

    for (int currentRow = 1; currentRow <= rows; currentRow++) // حلقه برای هر سطر // 1
    {
        
        // چاپ اعداد افزایشی در سطر فعلی
        for (int increasingNum = 1; increasingNum <= currentRow; increasingNum++) 
        {
            cout << increasingNum; // 1, 12
        }
        // چاپ اعداد کاهشی در سطر فعلی
        for (int decreasingNum = currentRow - 1; decreasingNum > 0; decreasingNum--) 
        {
            cout << decreasingNum; // , 1
        }
        cout << endl; // پایان سطر فعلی
    }

    return 0;
}
