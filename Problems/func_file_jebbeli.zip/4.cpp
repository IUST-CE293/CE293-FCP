#include <iostream>
using namespace std;

// 0 + 1 + 1 + 8 + 27 + 125
int fibo(int n) 
{
    if (n <= 1) 
    {
        return n;  
    } 
    else 
    {
        return fibo(n - 1) + fibo(n - 2);  
    }
}


int sumCubesFibo(int n) 
{
    if (n < 0) 
    {
        return 0;  
    }
    
    int fib = fibo(n);  
    return (fib * fib * fib) + sumCubesFibo(n - 1);  
}

int main() 
{
    int n;
    cin >> n;

    
    int res = sumCubesFibo(n - 1);  
    cout << res << endl;

    return 0;
}
