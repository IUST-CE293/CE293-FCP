#include <iostream>
// 6

using namespace std;
int fibo(int n) 
{
    if (n == 0) return 0;
    if (n == 1) return 1;
    return fibo(n - 1) + fibo(n - 2);
}


void fiboReverse(int n) 
{
    if (n < 0) return; 
    cout << fibo(n) << " "; 
    fiboReverse(n - 1); 
}

int main() 
{
    int n;
    cin >> n;

    fiboReverse(n);
    cout << endl;
    return 0;
}
