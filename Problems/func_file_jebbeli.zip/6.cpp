#include <iostream>
#include <cmath>

// 1234321
using namespace std;
int numDigits(int num) 
{
    int count = 0;
    while (num != 0) 
    {
        count++;
        num /= 10;
    }
    return count;
}


bool isPalindrome(int num) 
{
    
    if (num >= 0 && num < 10) 
    {
        return true;
    }

    
    int digits = numDigits(num);

    
    int firstDigit = num / (int)pow(10, digits - 1); // 1234
    int lastDigit = num % 10; 

    
    if (firstDigit != lastDigit) 
    {
        return false;
    }

    
    int newNum = (num % (int)pow(10, digits - 1)) / 10; // 4
    return isPalindrome(newNum);
}

int main() {
    int n;
    cin >> n;

    if (isPalindrome(n)) 
    {
        cout << n << " is a palindrome." << endl;
    } 
    else 
    {
        cout << n << " is not a palindrome." << endl;
    }

    return 0;
}
