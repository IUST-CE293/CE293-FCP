#include <iostream>
using namespace std;
int sumOfDigits(long long int num)  // 123456789
{
    if (num < 10) 
    {
        return num;
    }


    long long int sum = 0;
    while (num > 0) 
    {
        sum += num % 10; // 45
        num /= 10;      
    }


    return sumOfDigits(sum);
}

int main() 
{
    long long int n;
    cin >> n;

    long long int result = sumOfDigits(n);
    cout << "The single-digit result is: " << result << endl;

    return 0;
}
