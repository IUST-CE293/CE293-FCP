#include <iostream>
using namespace std;

// 245789
bool isPrime(int digit) 
{
    return (digit == 2 || digit == 3 || digit == 5 || digit == 7);
}


void checkDigit(int n) // 1234 , 123, 12, 1
{
    while (n > 0) 
    {
        int digit = n % 10;  
        if (isPrime(digit)) 
        {
            cout << digit << " is prime." << endl;  
        } 
        else
        {
            cout << digit << " is not prime." << endl;  
        }
        n /= 10;  
    }
}

int main() 
{
    int n;
    cin >> n;

    
    checkDigit(n);

    return 0;
}
