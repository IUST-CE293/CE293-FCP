#include <iostream>

using namespace std;

int GCD(int m, int n);

int main()
{
    int m, n;
    cin >> m;
    cin >> n;
    int res;
    res = GCD(m, n);
    cout << res;
}

int GCD(int m, int n)
{
    int temp;
    if(m % n == 0){return n;}
    
    temp = m % n;
    m = n;
    n = temp;
    GCD(m, n);
    
    return n;
}