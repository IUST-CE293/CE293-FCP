#include <iostream>
using namespace std;

// 0, 1, 1, 2, 3, 5 ==> 0 + 1 + 1 + 2 + 3
int fibo(int n) 
{
    if (n <= 1) 
    {
        return n;  
    }
    else 
    {
        return fibo(n - 1) + fibo(n - 2);  
    }
}


int sumFibo(int n) 
{
    if (n < 0) 
    {
        return 0;  
    }
    
    return fibo(n) + sumFibo(n - 1); // fibo(3) + sumFibo(2) /// fibo(2) + sumFib(!) // fibo(1) + sumFibo(0) // fibo(0) +0
}

int main() 
{
    int n;
    
    cin >> n;

    int res = sumFibo(n - 1);  
    cout << res << endl;
    return 0;
}
