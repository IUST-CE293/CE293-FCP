#include <iostream>

// 1, 10
using namespace std;
bool isOdd(int num) 
{
    return num % 2 != 0; 
}

int sumOddNumbers(int n) 
{
    int sum = 0;
    for (int i = 1; i < n; ++i) 
    {
        if (isOdd(i)) 
        {
            sum += i;
        }
    }
    return sum;
}

int main() 
{
    int n;
    cin >> n;

    int result = sumOddNumbers(n);
    cout << result << endl;

    return 0;
}
