#include<iostream>
using namespace std;
int main()
{
    float r,p,s;
    cout<<"Enter radius: ";
    cin>>r;
    s=3.14*r*r;
    p=2*r*3.14;
    cout<<"Area is "<<s<<" and perimeter is "<<p;
    return 0;
}