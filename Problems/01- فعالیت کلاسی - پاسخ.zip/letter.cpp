#include<iostream>
using namespace std;
int main()
{
    char a;
    cout<<"Enter a letter: ";
    cin>>a;
    if(a=='a' or a=='u' or a=='i' or a=='o' or a=='e')
    cout<<"The letter is vowel";
    else cout<<"The letter is consonant";
    return 0;
}
