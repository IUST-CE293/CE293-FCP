#include<iostream>
using namespace std;
int main()
{
    long long int n,i,j,sum=0;
    cin>>n;
    long long int A[n][n];
    for(i=0 ; i<n ; i++)
    {
        for(j=0 ; j<n ; j++)
        {
            cin>>A[i][j];
        }
    }
    for(i=0 ; i<n ; i++)
    {
        for(j=0 ; j<n ; j++)
        {
            if(i==j || i+j==n-1)
            {
                sum+=A[i][j];
            }
        }
    }
    cout<<sum;
}