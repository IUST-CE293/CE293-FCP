#include<iostream>
using namespace std;
int main()
{
    int n;
    cin>>n;
    int A[n][n],X[n]={0},Y[n]={0},m1=0,m2=0,base=0;
    for(int i=0 ; i<n ; i++)
    {
        for(int j=0 ; j<n ; j++)
        {
            cin>>A[i][j];
        }
    }
    for(int j=0 ; j<n ; j++)
    {
        base+=A[0][j];
    }
    for(int i=0 ; i<n ; i++)
    {
        for(int j=0 ; j<n ; j++)
        {
            X[i]+=A[i][j];
            Y[i]+=A[j][i];
            if(i==j)
            {
                m1+=A[i][j];
            }
            if(i+j==n-1)
            {
                m2+=A[i][j];
            }
        }
    }
    if(!(m1==base && m2==base))
    {
        cout<<"NO";
        return 0;
    }
    for(int i=0 ; i<n ; i++)
    {
        if(!(X[i]==base && Y[i]==base))
        {
            cout<<"NO";
            return 0;
        }
    }
    cout<<"YES";
    return 0;
}