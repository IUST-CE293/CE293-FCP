#include<iostream>
using namespace std;
int main()
{
    int m,n;
    cin>>m>>n;
    int A[m][n],B[n][m];
    for(int i=0 ; i<m ; i++)
    {
        for(int j=0 ; j<n ; j++)
        {
            cin>>A[i][j];
        }
    }
    for(int i=0 ; i<n ; i++)
    {
        for(int j=0 ; j<m ; j++)
        {
            B[i][j]=A[m-j-1][i];
        }
    }
    for(int i=0 ; i<n ; i++)
    {
        for(int j=0 ; j<m ; j++)
        {
            cout<<B[i][j]<<" ";
        }
        cout<<endl;
    }
}