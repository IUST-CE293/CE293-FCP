#include <iostream>
#include <string>
using namespace std;

int main()
{
    int shiraz1, shiraz2, shiraz3;
    int mashhad1, mashhad2, mashhad3;
    int tehran1, tehran2, tehran3, tehran4, tehran5, tehran6, tehran7, tehran8;
    int esfahan1, esfahan2, esfahan3;
    int tabriz1, tabriz2, tabriz3;
    int ahvaz1, ahvaz2;

    shiraz1 = 228;
    shiraz2 = 229;
    shiraz3 = 230;
    mashhad1 = 92;
    mashhad2 = 93;
    mashhad3 = 94;
    tehran1 = 1;
    tehran2 = 2;
    tehran3 = 3;
    tehran4 = 4;
    tehran5 = 5;
    tehran6 = 6;
    tehran7 = 7;
    tehran8 = 8;
    esfahan1 = 127;
    esfahan2 = 128;
    esfahan3 = 129;
    tabriz1 = 136;
    tabriz2 = 137;
    tabriz3 = 138;
    ahvaz1 = 174;
    ahvaz2 = 175;


    long long int snn;
    int control_digit;
    cin >> snn;

    int calculations; // 0021458766
    calculations = 0;
    calculations += ((snn / 10) % 10) * 2; // + (6 * 2)
    calculations += ((snn / 100) % 10) * 3; // + (7 * 3)
    calculations += ((snn / 1000) % 10) * 4; // + (8 * 4)
    calculations += ((snn / 10000) % 10) * 5; // + (5 * 5)
    calculations += ((snn / 100000) % 10) * 6; // + (4 * 6)
    calculations += ((snn / 1000000) % 10) * 7; // + (1 * 7)
    calculations += ((snn / 10000000) % 10) * 8; // + (2 * 8)
    calculations += ((snn / 100000000) % 10) * 9; // + (0 * 9)
    calculations += ((snn / 1000000000) % 10) * 10; // + (0 * 10)
    calculations %= 11;


    control_digit = snn % 10;
    if (calculations >= 2)
    {
        if (control_digit != (11 - calculations))
        {
            cout << 'n' << endl;
        }

        else
        {
            cout << 'y' << endl;
            int city; // 773168995x
            city = 0;
            city += ((snn / 10000000) % 10) * 1; // + 3
            city += ((snn / 100000000) % 10) * 10; // + 70
            city += ((snn / 1000000000) % 10) * 100; // + 700
            
            if (city == shiraz1 || city == shiraz2 || city == shiraz3)
            {
                cout << "shiraz" << endl;
            }

            else if (city == mashhad1 || city == mashhad2 || city == mashhad3)
            {
                cout << "mashhad" << endl;
            }

            else if (city == tehran1 || city == tehran2 || city == tehran3 || city == tehran4 || city == tehran5 || city == tehran6 || city == tehran7 || city == tehran8)
            {
                cout << "tehran" << endl;
            }

            else if (city == esfahan1 || city == esfahan2 || city == esfahan3)
            {
                cout << "esfahan" << endl;
            }

            else if (city == tabriz1 || city == tabriz2 || city == tabriz3)
            {
                cout << "tabriz" << endl;
            }

            else if (city == ahvaz1 || city == ahvaz2)
            {
                cout << "ahvaz" << endl;
            }
        }
        
    }

    else
    {
        if (control_digit != calculations)
        {
            cout << 'n' << endl;
        }

        else
        {
            cout << 'y' << endl;
            int city; // 773168995x
            city = 0;
            city += ((snn / 10000000) % 10) * 1; // + 3
            city += ((snn / 100000000) % 10) * 10; // + 70
            city += ((snn / 1000000000) % 10) * 100; // + 700
            if (city == shiraz1 || city == shiraz2 || city == shiraz3)
            {
                cout << "shiraz" << endl;
            }

            else if (city == mashhad1 || city == mashhad2 || city == mashhad3)
            {
                cout << "mashhad" << endl;
            }

            else if (city == tehran1 || city == tehran2 || city == tehran3 || city == tehran4 || city == tehran5 || city == tehran6 || city == tehran7 || city == tehran8)
            {
                cout << "tehran" << endl;
            }

            else if (city == esfahan1 || city == esfahan2 || city == esfahan3)
            {
                cout << "esfahan" << endl;
            }

            else if (city == tabriz1 || city == tabriz2 || city == tabriz3)
            {
                cout << "tabriz" << endl;
            }

            else if (city == ahvaz1 || city == ahvaz2)
            {
                cout << "ahvaz" << endl;
            }
        }
    }

}