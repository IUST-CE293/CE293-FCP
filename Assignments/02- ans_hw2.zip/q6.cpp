#include <iostream>
#include <string>

using namespace std;

int main()
{
    string b_date;
    cin >> b_date;
    string year1, month1, day1;
    year1 = b_date.substr(0, 4);
    month1 = b_date.substr(5, 2);
    day1 = b_date.substr(8, 2);

    string date; 
    cin >> date;
    string year2, month2, day2;
    year2 = date.substr(0, 4);
    month2 = date.substr(5, 2);
    day2 = date.substr(8, 2);

    int m1,m2,d1,d2;
    m1 = stoi(month1);
    m2 = stoi(month2);
    d1 = stoi(day1);
    d2 = stoi(day2);

    int the_number_of_days1, the_number_of_days2;


    the_number_of_days1 = 0;
    the_number_of_days2 = 0;

    int smaller_number_m, smaller_number_d, bigger_number_m, bigger_number_d;
    smaller_number_m = 1;
    smaller_number_d = 1;
    if(m1 <= m2)
    {
        smaller_number_m = m1;
        smaller_number_d = d1;
        bigger_number_m = m2;
        bigger_number_d = d2;
    }
        
    else
    {
        smaller_number_m = m2;
        smaller_number_d = d2;
        bigger_number_m = m1;
        bigger_number_d = d1;
    }
        

if(smaller_number_m == 1 || smaller_number_m == 2 || smaller_number_m == 3 || smaller_number_m == 4 || smaller_number_m == 5 || smaller_number_m == 6)
    {
        the_number_of_days1 = 31;
    }
    
else if(smaller_number_m == 7 || smaller_number_m == 8 || smaller_number_m == 9 || smaller_number_m == 10 || smaller_number_m == 11)
      {
        the_number_of_days1 = 30;
      }
    
else if(smaller_number_m == 12)
{
    the_number_of_days1 = 29;
}
    
int the_number_of_days_after_the_beginning_of_the_year1, the_number_of_days_after_the_beginning_of_the_year2;

the_number_of_days_after_the_beginning_of_the_year1 = 0;
the_number_of_days_after_the_beginning_of_the_year2 = 0;

if(m2 == 1)
    the_number_of_days_after_the_beginning_of_the_year1 = 0 + d2;
else if(m2 == 2)
    the_number_of_days_after_the_beginning_of_the_year1 = 31 + d2;
else if(m2 == 3)
    the_number_of_days_after_the_beginning_of_the_year1 = 62 + d2;
else if(m2 == 4)
    the_number_of_days_after_the_beginning_of_the_year1 = 93 + d2;
else if(m2 == 5)
    the_number_of_days_after_the_beginning_of_the_year1 = 124 + d2;
else if(m2 == 6)
    the_number_of_days_after_the_beginning_of_the_year1 = 155 + d2;
else if(m2 == 7)
    the_number_of_days_after_the_beginning_of_the_year1 = 186 + d2;
else if(m2 == 8)
    the_number_of_days_after_the_beginning_of_the_year1 = 216 + d2;
else if(m2 == 9)
    the_number_of_days_after_the_beginning_of_the_year1 = 246 + d2;
else if(m2 == 10)
    the_number_of_days_after_the_beginning_of_the_year1 = 276 + d2;
else if(m2 == 11)
    the_number_of_days_after_the_beginning_of_the_year1 = 306 + d2;
else if(m2 == 12)
    the_number_of_days_after_the_beginning_of_the_year1 = 336 + d2;



if(m1 == 1)
    the_number_of_days_after_the_beginning_of_the_year2 = 0 + d1;
else if(m1 == 2)
    the_number_of_days_after_the_beginning_of_the_year2 = 31 + d1;
else if(m1 == 3)
    the_number_of_days_after_the_beginning_of_the_year2 = 62 + d1;
else if(m1 == 4)
    the_number_of_days_after_the_beginning_of_the_year2 = 93 + d1;
else if(m1 == 5)
    the_number_of_days_after_the_beginning_of_the_year2 = 124 + d1;
else if(m1 == 6)
    the_number_of_days_after_the_beginning_of_the_year2 = 155 + d1;
else if(m1 == 7)
    the_number_of_days_after_the_beginning_of_the_year2 = 186 + d1;
else if(m1 == 8)
    the_number_of_days_after_the_beginning_of_the_year2 = 216 + d1;
else if(m1 == 9)
    the_number_of_days_after_the_beginning_of_the_year2 = 246 + d1;
else if(m1 == 10)
    the_number_of_days_after_the_beginning_of_the_year2 = 276 + d1;
else if(m1 == 11)
    the_number_of_days_after_the_beginning_of_the_year2 = 306 + d1;
else if(m1 == 12)
    the_number_of_days_after_the_beginning_of_the_year2 = 336 + d1;

int number_of_days;
if(m1 < m2)
    number_of_days = (the_number_of_days_after_the_beginning_of_the_year1) - the_number_of_days_after_the_beginning_of_the_year2 + 1;
else
    number_of_days = (the_number_of_days_after_the_beginning_of_the_year1) - the_number_of_days_after_the_beginning_of_the_year2 - 1;
if(number_of_days < 0)
    // print(f'+{-1*number_of_days}')
    cout << '+' << -1*number_of_days << endl;
else
    // print(f'-{number_of_days}')
    cout << '-' << number_of_days << endl;


}