#include <iostream>
using namespace std;

int main()
{
    int r, c;
    cin >> r >> c;

    if (c < 11)
    {
        cout << "Right" << " ";
        cout << 11 - r << " ";
        cout << c;
    }
    else
    {
        cout << "Left" << " ";
        cout << 11 - r << " ";
        cout << 21 - c;
    }
}
