#include <iostream>
#include <cmath>
using namespace std;
// 12345 , 23456
int main()
{
    int number;

    cin >> number;
    int output;
    output = 0;

    if (number % 2 == 0)
    {
        // 23456
        output += pow(10, 4) * ((number / 1) % 10); // 60000
        output += pow(10, 3) * ((number / 10) % 10); // 65000
        output += pow(10, 2) * ((number / 100) % 10); // 65400
        output += pow(10, 1) * ((number / 1000) % 10); // 65432
        output += pow(10, 0) * ((number / 10000) % 10); // 65432
    }

    else
    {
        // 12345
        output += pow(10, 4) * ((number / 10) % 10); // 40000
        output += pow(10, 3) * ((number / 1) % 10); // 45000
        output += pow(10, 2) * ((number / 100) % 10); // 45300
        output += pow(10, 1) * ((number / 10000) % 10); // 45310
        output += pow(10, 0) * ((number / 1000) % 10); // 45312
    }
    
    cout << output << endl;
}
