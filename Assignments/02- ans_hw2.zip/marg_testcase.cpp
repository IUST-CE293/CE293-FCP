#include <iostream>
using namespace std;

int main()
{
    int n;
    cin >> n;

    if (n % 5 == 0)
    {
        cout << "Mashalla Hashem!" << endl;
    }
    else
    {
        cout << "Mashalla Milad!" << endl;
    }

    return 0;
}
