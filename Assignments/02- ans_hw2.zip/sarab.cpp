#include <iostream>
using namespace std;

int main()
{
    int x, y;
    cin >> x >> y;

    if (x == y || x == y + 2)
    {
        if (x % 2 == 0)
        {
            cout << x + y;
        }
        else
        {
            cout << x + y - 1;
        }
    }
    else
    {
        cout << -1;
    }

    return 0;
}
