#include <iostream>
#include <cmath>
using namespace std;

int main()
{
    int m[3][2];
    int n[2][3];
    for (int i = 0; i < 3; i++)
    {
        int num;
        for (int j = 0; j < 2; j++)
        {
            cin >> num;
            m[i][j] = num;
        }
    }
    for (int i = 0; i < 2; i++)
    {
        int num;
        for (int j = 0; j < 3; j++)
        {
            cin >> num;
            n[i][j] = num;
        }
    }

    int answer[3][3];
    for (int i = 0; i < 3; i++)
    {
        for (int j = 0; j < 3; j++)
        {
            answer[i][j] = 0;
            for (int k = 0; k < 2; k++)
            {
                answer[i][j] += m[i][k] * n[k][j];
            }
        }
        
    }
    for (int i = 0; i < 3; i++)
    {
        for (int j = 0; j < 3; j++)
        {
            cout << answer[i][j] << " ";
        }
        cout << endl;
    }    
    //
    // 00  01  02
    // 10  11  12
    // 20  21  22
    //
    int det[3];
    det[0] = answer[0][0] * (answer[1][1] * answer[2][2] - answer[1][2] * answer[2][1]);
    det[1] = answer[0][1] * (answer[1][0] * answer[2][2] - answer[1][2] * answer[2][0]);
    det[2] = answer[0][2] * (answer[1][0] * answer[2][1] - answer[1][1] * answer[2][0]);
    int inpuut = det[0] - det[1] + det[2];
    cout << "det(mxn) is: " << inpuut;
}