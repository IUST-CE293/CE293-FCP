#include <iostream>
using namespace std;

int main() {
    int base, exponent;
    //cout << "Enter base: ";
    cin >> base;
    //cout << "Enter exponent: ";
    cin >> exponent;

    // محاسبه base^exponent بدون استفاده از ضرب و توابع
    int result = 1;
    for (int i = 0; i < exponent; i++) {
        int temp = 0; // موقت برای جمع کردن مقدار result
        for (int j = 0; j < result; j++) {
            temp += base; // temp برابر با base * result می‌شود
        }
        result = temp; // مقدار جدید result برابر با نتیجه محاسبه قبلی
    }

    cout << result << endl;
    return 0;
}
