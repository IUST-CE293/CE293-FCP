#include <iostream>
#include <iomanip> // 4raqam aashar
using namespace std;

int F_nearestSquare(int number, int rootB) {
    if (number < 0) {
        cout << "Exception: not negative number!" << endl;
        return 0;
    }
    if (number <= rootB * rootB)
        return rootB;
    return F_nearestSquare(number, rootB + 1); // تابع بازگشتی
}

int main() {
    int number;
    //cout << "Enter a number: ";
    cin >> number;
    bool lowerthan1000=false;
    if(number<1000){
        number*=400;
        lowerthan1000=true;
    }
    int near = F_nearestSquare(number, 0);
    // چک کردن اینکه کدام ریشه‌ی تقریبی نزدیک‌تر است
    if (((near * near)-number) > (number - (near - 1) * (near - 1))) {
        near -= 1;
    }
    long double final_answer = near;
    int i = 0, j;
    long int differ = 1;
    long double zarib, final_zarib = 1, D_moshtaqe_rad = 1, f_moshtaqe_rad;

    // بسط تیلور تا دقت چهار جمله
    while (i < 4) {
        zarib = (1.0 / 2.0) - i;
        final_zarib *= zarib;
        differ *= (number - (near*near));

        if (i > 0) {
            D_moshtaqe_rad *= (near * near);
        }
        f_moshtaqe_rad = (1 / (near * D_moshtaqe_rad));

        long long int fact = 1;     /* while factorial structure! (you can make it also with recursive function) */
        for (j = 1; j <= i; j++) {
            fact *= j;
        }
        final_answer += (final_zarib * f_moshtaqe_rad * differ) / fact;
        i++;
    }
    if(lowerthan1000)
        final_answer/=20;
    cout << fixed << setprecision(4);
    cout << "Approximate square root: " << final_answer << endl;
    return 0;
}
