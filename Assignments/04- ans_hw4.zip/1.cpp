#include <iostream>
#include <string>
using namespace std;

int main()
{
    int a00, a01, a02, a03;
    int a10, a11, a12, a13;
    int a20, a21, a22, a23;
    int a30, a31, a32, a33;
    

    cin >> a00 >> a01 >> a02 >> a03;
    cin >> a10 >> a11 >> a12 >> a13;
    cin >> a20 >> a21 >> a22 >> a23;
    cin >> a30 >> a31 >> a32 >> a33;
    

    int number;
    int sum;
    cin >> number;
    sum = 0;
    string ainumber;
    for (int i = 0; i <= 3; i++)
    {
        for (int j = number; j <= number; j++)
        {
            ainumber = "a" + to_string(i) + to_string(number);
            if (i == 0)
            {
                if(ainumber == "a00")
                {
                    sum += a00;
                }

                else if(ainumber == "a01")
                {
                    sum += a01;
                }

                else if(ainumber == "a02")
                {
                    sum += a02;
                }

                else if(ainumber == "a03")
                {
                    sum += a03;
                }
            }
            

            else if (i == 1)
            {
                if(ainumber == "a10")
                {
                    sum += a10;
                }

                else if(ainumber == "a11")
                {
                    sum += a11;
                }

                else if(ainumber == "a12")
                {
                    sum += a12;
                }

                else if(ainumber == "a13")
                {
                    sum += a13;
                }
            }

            else if (i == 2)
            {
                if(ainumber == "a20")
                {
                    sum += a20;
                }

                else if(ainumber == "a21")
                {
                    sum += a21;
                }

                else if(ainumber == "a22")
                {
                    sum += a22;
                }

                else if(ainumber == "a23")
                {
                    sum += a23;
                }
            }

            else if (i == 3)
            {
                if(ainumber == "a30")
                {
                    sum += a30;
                }

                else if(ainumber == "a31")
                {
                    sum += a31;
                }

                else if(ainumber == "a32")
                {
                    sum += a32;
                }

                else if(ainumber == "a33")
                {
                    sum += a33;
                }
            }
        }
        ainumber = "";
    }

    cout << sum << endl;
}