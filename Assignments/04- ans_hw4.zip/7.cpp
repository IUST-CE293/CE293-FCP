#include <iostream>
#include <string>

using namespace std;

int main() {
    string reshte;
   
    getline(cin, reshte); // خواندن ورودی به صورت رشته شامل فاصله

    string stt = "";
    string uniqueChars = ""; // رشته برای ذخیره کاراکترهای منحصر به فرد

    int len_reshte = reshte.length();

    for (int i = 0; i < len_reshte; ++i) {
        int exists = 0; // متغیر برای بررسی وجود کاراکتر (صفر یا یک)

        // بررسی اینکه آیا کاراکتر قبلاً در uniqueChars وجود دارد یا نه
        for (int k = 0; k < uniqueChars.length(); ++k) {
            if (reshte[i] == uniqueChars[k]) {
                exists = 1; // اگر کاراکتر پیدا شد، exists را 1 می‌کنیم
                break; 
            }
        }

        if (exists == 0) { // اگر کاراکتر وجود نداشت
            // جمع‌آوری تکرارهای کاراکتر
            for (int j = 0; j < len_reshte; ++j) {
                if (reshte[i] == reshte[j]) {
                    stt += reshte[j]; // اضافه کردن کاراکتر به رشته نتیجه
                }
            }
            uniqueChars += reshte[i]; // اضافه کردن کاراکتر به رشته منحصر به فرد
        }
    }

    cout << stt << endl;

    return 0;
}