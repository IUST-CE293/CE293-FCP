#include <iostream>
#include <string>
using namespace std;

int main()
{
    double a00, a01, a02, a03;
    double a10, a11, a12, a13;
    double a20, a21, a22, a23;
    double a30, a31, a32, a33;
    

    cin >> a00 >> a01 >> a02 >> a03;
    cin >> a10 >> a11 >> a12 >> a13;
    cin >> a20 >> a21 >> a22 >> a23;
    cin >> a30 >> a31 >> a32 >> a33;

    string secondary_sum;
    secondary_sum = "";

    string ainumber;
    for (int i = 0; i <= 3; i++)
    {
        for (int j = 0; j <= 3; j++)
        {
            ainumber = "a" + to_string(i) + to_string(j); 
            if (i == 0)
            {
                if(ainumber == "a00")
                {
                    cout << "Main Diagonal: ";
                    cout << a00 << " ";
                }
            }
            

            else if (i == 1)
            {

                if(ainumber == "a11")
                {
                    cout << a11 << " ";
                }

            }

            else if (i == 2)
            {

                if(ainumber == "a22")
                {
                    cout << a22 << " ";
                }
            }

            else if (i == 3)
            {
                if(ainumber == "a33")
                {
                    cout << a33 << " ";
                }
            }
        }
        ainumber = ""; 
    }

    cout << endl;

    for (int i = 0; i <= 3; i++)
    {
        for (int j = 0; j <= 3; j++)
        {
            ainumber = "a" + to_string(i) + to_string(j); 
            if (i == 0)
            {
                if(ainumber == "a03")
                    
                    {
                        cout << "Secondary Diagonal: ";
                        cout << a03 << " ";
                    }
            }
            

            else if (i == 1)
            {
                if(ainumber == "a12")
                {
                    cout << a12 << " ";
                }
            }

            else if (i == 2)
            {
                 if(ainumber == "a21")
                {
                    cout << a21 << " ";
                }
            }

            else if (i == 3)
            {
                if(ainumber == "a30")
                {
                    cout << a30 << " ";
                }
            }
        }
        ainumber = ""; 
    }
}