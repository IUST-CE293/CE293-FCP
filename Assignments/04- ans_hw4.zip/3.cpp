#include <iostream>
using namespace std;

int main() {
    int arr[20];
    int target;

    // دریافت آرایه ۲۰ تایی از کاربر
    //cout << "Enter 20 integers:" << endl;
    for (int i = 0; i < 20; i++) {
        cin >> arr[i];
    }

    // مرتب‌سازی آرایه با روش Bubble Sort
    for (int i = 0; i < 20 - 1; i++) {
        for (int j = 0; j < 20 - i - 1; j++) {
            if (arr[j] > arr[j + 1]) {
                // جابه‌جایی عناصر بدون استفاده از متغیر temp
                arr[j] += arr[j + 1];
                arr[j + 1] = arr[j] - arr[j + 1];
                arr[j] -= arr[j + 1];
            }
        }
    }

    // دریافت عدد برای جستجو
    //cout << "Enter the number to search: ";
    cin >> target;

    // نمایش آرایه مرتب شده
    //cout << "Sorted array:" << endl;
    for (int i = 0; i < 20; i++) {
        cout << arr[i] << " ";
    }
    cout << endl;

    // تعیین مقادیر اولیه برای سقف و کف
    int left = 0, right = 19; // اندیس‌های اول و آخر آرایه

    // جستجو با روش Binary Search
    bool found = false;
    while (left <= right) {
        int mid = left + (right - left) / 2;
        if (arr[mid] == target) {
            cout << "Number found at index: " << mid << endl;
            found = true;
            break;
        }
        if (arr[mid] < target)
            left = mid + 1; // جستجو در نیمه راست
        else
            right = mid - 1; // جستجو در نیمه چپ
    }

    if (!found) {
        cout << "Error: Number not found!" << endl;
    }

    return 0;
}
