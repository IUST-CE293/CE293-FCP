#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

// Calculate trapped water between wells
long long calc_trapped_water(int n, vector<int>& heights) {
    if (n <= 2) return 0;

    long long total_water = 0;
    vector<int> left_max(n), right_max(n);

    // Fill left_max array - maximum height encountered from left
    left_max[0] = heights[0];
    for (int i = 1; i < n; i++) {
        left_max[i] = max(left_max[i - 1], heights[i]);
    }

    // Fill right_max array - maximum height encountered from right
    right_max[n - 1] = heights[n - 1];
    for (int i = n - 2; i >= 0; i--) {
        right_max[i] = max(right_max[i + 1], heights[i]);
    }

    // For each position, calculate trapped water
    for (int i = 1; i < n - 1; i++) {
        // Water level at each point is determined by the minimum of
        // maximum heights from both sides
        int water_level = min(left_max[i], right_max[i]);

        // If water level is higher than current height, water is trapped
        if (water_level > heights[i]) {
            total_water += water_level - heights[i];
        }
    }

    return total_water;
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    // Read input
    int n;
    cin >> n;

    vector<int> heights(n);
    for (int i = 0; i < n; i++) {
        cin >> heights[i];
    }

    // Calculate and output result
    cout << calc_trapped_water(n, heights) << endl;

    return 0;
}