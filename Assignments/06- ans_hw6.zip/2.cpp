#include <iostream>

using namespace std;



void Bubble(int* arr, int s) {

    for (int a = 0; a < s - 1; ++a) {

        for (int b = 0; b < s - a - 1; ++b) {

            if (arr[b] > arr[b + 1]) {

                int temp = arr[b];

                arr[b] = arr[b + 1];

                arr[b + 1] = temp;

            }

        }

    }

}



int main() {

    int c, d;

    cin >> c >> d ;

    int TotalSize = c + d;

    int* MergedArray = new int[TotalSize];



    for(int a = 0; a < c; ++a) {

        cin >> MergedArray[a];

    }



    for(int a = c; a < TotalSize; ++a) {

        cin >> MergedArray[a];

    }



    Bubble(MergedArray, TotalSize);



    for(int a = 0; a < TotalSize; ++a) {

        cout << MergedArray[a] << ' ';

    }

   cout << endl;





    return 0;

}

