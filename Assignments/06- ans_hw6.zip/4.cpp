#include <iostream>
using namespace std;
int arr[100000];
int temp[100000];
// This function performs a right shift by k positions
void shiftArray(int arr[], int n, int k) {
    // If k is larger than n, we can reduce k since shifts repeat every n positions
    k = k % n;

    if (k == 0) return;  // No need to shift

    // Create a temporary array to store the last k elements
   
    for (int i = 0; i < k; i++) {
        temp[i] = arr[n - k + i];
    }

    // Shift the first (n-k) elements to the right
    for (int i = n - 1; i >= k; i--) {
        arr[i] = arr[i - k];
    }

    // Place the temporary elements at the start
    for (int i = 0; i < k; i++) {
        arr[i] = temp[i];
    }
}

int main() {
    // For faster input/output
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    int n, k;
    cin >> n >> k;

    // Declare array with size n // Using maximum possible size

    // Read array elements
    for (int i = 0; i < n; i++) {
        cin >> arr[i];
    }

    // Perform the shift
    shiftArray(arr, n, k);

    // Print the result
    for (int i = 0; i < n; i++) {
        cout << arr[i];
        if (i < n - 1) cout << " ";
    }
    cout << endl;

    return 0;
}