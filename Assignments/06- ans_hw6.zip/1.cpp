#include <iostream>
using namespace std;

// We'll use a single array of size 81 (9x9) to store the Sudoku grid
// To access position (row,col), we use: row*9 + col

bool checkSudoku(int grid[81]) {
    // Array to mark used numbers (1-9)
    bool used[9];

    // Check rows
    for (int row = 0; row < 9; row++) {
        // Reset the used array for each row
        for (int i = 0; i < 9; i++) used[i] = false;

        // Check each number in this row
        for (int col = 0; col < 9; col++) {
            int num = grid[row * 9 + col] - 1;  // Subtract 1 to use 0-based indexing
            // If number already used in this row, Sudoku is invalid
            if (used[num]) return false;
            used[num] = true;
        }
    }

    // Check columns
    for (int col = 0; col < 9; col++) {
        // Reset the used array for each column
        for (int i = 0; i < 9; i++) used[i] = false;

        // Check each number in this column
        for (int row = 0; row < 9; row++) {
            int num = grid[row * 9 + col] - 1;
            if (used[num]) return false;
            used[num] = true;
        }
    }

    // Check 3x3 blocks
    for (int blockRow = 0; blockRow < 3; blockRow++) {
        for (int blockCol = 0; blockCol < 3; blockCol++) {
            // Reset the used array for each 3x3 block
            for (int i = 0; i < 9; i++) used[i] = false;

            // Check each cell in this 3x3 block
            for (int row = 0; row < 3; row++) {
                for (int col = 0; col < 3; col++) {
                    // Calculate the actual position in the 1D array
                    int actualRow = blockRow * 3 + row;
                    int actualCol = blockCol * 3 + col;
                    int num = grid[actualRow * 9 + actualCol] - 1;

                    if (used[num]) return false;
                    used[num] = true;
                }
            }
        }
    }

    // If we get here, the Sudoku is valid
    return true;
}

int main() {
    // Use a single array for the entire grid
    int grid[81];

    // Read the Sudoku grid
    for (int i = 0; i < 81; i++) {
        cin >> grid[i];
    }

    // Check and output result
    cout << (checkSudoku(grid) ? "Valid" : "NotValid") << endl;

    return 0;
}