//#include <iostream>
//#include <fstream>
//#include <vector>
//#include <set>
//#include <cstdlib>
//#include <ctime>
//#include <direct.h> // For _mkdir
//#include <string>
//
//using namespace std;
//
//// Function to generate a test case
//void generate_test(const string& filename, int n) {
//    ofstream fout(filename.c_str());
//    if (!fout.is_open()) {
//        cout << "Error: Could not open file " << filename << endl;
//        return;
//    }
//
//    // Generate n distinct random weights between 1 and 100
//    set<int> used_weights;
//
//    fout << n << endl;
//    for (int i = 0; i < n; i++) {
//        int weight;
//        do {
//            weight = rand() % 100 + 1;  // Random number between 1 and 100
//        } while (used_weights.count(weight) > 0);
//        used_weights.insert(weight);
//
//        fout << weight;
//        if (i < n - 1) fout << " ";
//    }
//    fout << endl;
//    fout.close();
//}
//
//int main() {
//    // Set random seed
//    srand(static_cast<unsigned>(time(0)));
//
//    // Create directory if it doesn't exist
//    _mkdir("in");
//
//    // Test case sizes
//    vector<int> test_sizes = { 5, 10, 20, 50, 100, 100, 100, 100, 100, 100 };
//
//    // Generate test cases
//    for (int i = 0; i < test_sizes.size(); i++) {
//        string filename = "in/input" + to_string(i + 1) + ".txt";
//        cout << "Generating test case " << (i + 1) << " with n = " << test_sizes[i] << endl;
//        generate_test(filename, test_sizes[i]);
//    }
//
//    cout << "\nTest generation completed!" << endl;
//    cout << "Generated " << test_sizes.size() << " test cases in the 'in' directory." << endl;
//
//    return 0;
//}


#include <iostream>
#include <vector>
#include <utility>

using namespace std;

int solve_watermelon_contest(int n, vector<int>& weights) {
    // Create a vector of pairs (index, weight) where index starts from 1
    vector<pair<int, int>> watermelons;
    for (int i = 0; i < n; i++) {
        watermelons.push_back({ i + 1, weights[i] });
    }

    // Continue until only one watermelon remains
    while (watermelons.size() > 1) {
        // Compare weights of first two watermelons
        if (watermelons[0].second < watermelons[1].second) {
            // Remove the first (lighter) watermelon
            watermelons.erase(watermelons.begin());
        }
        else {
            // Remove the second (lighter) watermelon
            watermelons.erase(watermelons.begin() + 1);
        }
    }

    // Return the index of the remaining watermelon
    return watermelons[0].first;
}

int main() {
    int n;
    cin >> n;

    vector<int> weights(n);
    for (int i = 0; i < n; i++) {
        cin >> weights[i];
    }

    cout << solve_watermelon_contest(n, weights) << endl;

    return 0;
}