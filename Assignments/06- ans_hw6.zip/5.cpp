#include <iostream>
using namespace std;

// Since we're working with English letters only, we can use a smaller array
// We need space for both uppercase (65-90) and lowercase (97-122) ASCII values
bool checkAnagram(const char* str1, const char* str2, int length) {
    // Create frequency array for all ASCII characters
    int freq[128] = { 0 };  // Initialize all to zero

    // Count frequencies in first string
    for (int i = 0; i < length; i++) {
        freq[str1[i]]++;
    }

    // Subtract frequencies from second string
    for (int i = 0; i < length; i++) {
        freq[str2[i]]--;
        // If any character goes negative, they're not anagrams
        if (freq[str2[i]] < 0) {
            return false;
        }
    }

    // If we have same lengths and no negative frequencies,
    // and all used characters balanced out, we have an anagram
    return true;
}

int main() {
    // For faster input/output
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    int n;
    cin >> n;

    // Buffer for reading strings
    // Problem constraints don't specify max length, but it's reasonable
    // to assume it won't be extremely large. Let's use 1000 to be safe.
    const int MAX_LENGTH = 1000;
    char word1[MAX_LENGTH + 1];  // +1 for null terminator
    char word2[MAX_LENGTH + 1];

    // Process each pair of words
    while (n--) {
        int length;
        cin >> length;

        // Read the words character by character
        // This is more efficient than using string
        for (int i = 0; i < length; i++) {
            cin >> word1[i];
        }
        word1[length] = '\0';  // Null terminate

        for (int i = 0; i < length; i++) {
            cin >> word2[i];
        }
        word2[length] = '\0';  // Null terminate

        // Check and output result
        cout << (checkAnagram(word1, word2, length) ? "YES" : "NO") << "\n";
    }

    return 0;
}