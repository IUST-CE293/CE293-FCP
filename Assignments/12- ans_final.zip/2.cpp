#include <iostream>
#include <vector>
using namespace std;


void func1(vector<int>& nums, int n) {
    int ss = 1 << n; 

    cout << "t" << endl; 

    
    for (int si = 1; si <= n; si++) { 
        for (int ma = 1; ma < ss; ma++) { 
            vector<int> subset;
            int count = 0;

            for (int i = 0; i < n; i++) {
                if (ma & (1 << i)) {
                    subset.push_back(nums[i]);
                    count++;
                }
            }

            if (count == si) { 
                for (int num : subset) {
                    cout << num << " ";
                }
                cout << endl;
            }
        }
    }
}

int main() {
    int n;
    cin >> n;

    vector<int> nums(n);
    
    for (int i = 0; i < n; i++) {
        cin >> nums[i];
    }

    
    func1(nums, n);

    return 0;
}
