#include <iostream>
#include <vector>
using namespace std;


class Book {
public:
    string title, author;
    int year;
    bool isAvailable;

    
    Book(string t, string a, int y) {
        title = t;
        author = a;
        year = y;
        isAvailable = true; 
    }

    
    void print() {
        cout << "عنوان: " << title << "\n";
        cout << "نویسنده: " << author << "\n";
        cout << "سال انتشار: " << year << "\n";
        cout << "وضعیت: " << (isAvailable ? "موجود" : "امانت داده شده") << "\n\n";
    }

    
    void toggleAvailability() {
        isAvailable = !isAvailable;
    }
};


class Library {
public:
    vector<Book> books;

    
    void addBook() {
        string title, author;
        int year;
        cout << "عنوان کتاب: ";
        cin.ignore();
        getline(cin, title);
        cout << "نویسنده: ";
        getline(cin, author);
        cout << "سال انتشار: ";
        cin >> year;

        books.push_back(Book(title, author, year));
        cout << "کتاب اضافه شد!\n\n";
    }

    
    void searchBook() {
        string searchTitle;
        cout << "عنوان کتاب: ";
        cin.ignore();
        getline(cin, searchTitle);
        
        for (Book &b : books) {
            if (b.title == searchTitle) {
                cout << "کتاب یافت شد:\n";
                b.print();
                return;
            }
        }
        cout << "کتاب مورد نظر پیدا نشد.\n\n";
    }

    
    void showAllBooks() {
        if (books.empty()) {
            cout << "هیچ کتابی در کتابخانه وجود ندارد.\n\n";
            return;
        }

        cout << "لیست کتاب‌های موجود:\n";
        for (size_t i = 0; i < books.size(); i++) {
            cout << i + 1 << ". ";
            books[i].print();
        }
    }

    
    void lendBook() {
        string searchTitle;
        cout << "عنوان کتاب برای امانت: ";
        cin.ignore();
        getline(cin, searchTitle);
        
        for (Book &b : books) {
            if (b.title == searchTitle) {
                if (b.isAvailable) {
                    b.toggleAvailability();
                    cout << "کتاب امانت داده شد!\n\n";
                } else {
                    cout << "این کتاب قبلاً امانت داده شده است.\n\n";
                }
                return;
            }
        }
        cout << "کتاب مورد نظر پیدا نشد.\n\n";
    }

    
    void returnBook() {
        string searchTitle;
        cout << "عنوان کتاب برای بازگرداندن: ";
        cin.ignore();
        getline(cin, searchTitle);
        
        for (Book &b : books) {
            if (b.title == searchTitle) {
                if (!b.isAvailable) {
                    b.toggleAvailability();
                    cout << "کتاب بازگردانده شد!\n\n";
                } else {
                    cout << "این کتاب قبلاً موجود بوده است.\n\n";
                }
                return;
            }
        }
        cout << "کتاب مورد نظر پیدا نشد.\n\n";
    }
};

int main() {
    Library library;
    char choice;

    while (true) {
        cout << "=== سیستم مدیریت کتابخانه ===\n";
        cout << "1. افزودن کتاب جدید\n";
        cout << "2. جستجوی کتاب\n";
        cout << "3. نمایش کتاب‌های موجود\n";
        cout << "4. امانت گرفتن کتاب\n";
        cout << "5. بازگرداندن کتاب\n";
        cout << "6. خروج\n";
        cout << "انتخاب: ";
        cin >> choice;

        switch (choice) {
            case '1':
                library.addBook();
                break;
            case '2':
                library.searchBook();
                break;
            case '3':
                library.showAllBooks();
                break;
            case '4':
                library.lendBook();
                break;
            case '5':
                library.returnBook();
                break;
            case '6':
                cout << "خروج از سیستم.\n";
                return 0;
            default:
                cout << "گزینه‌ی نامعتبر! لطفاً دوباره امتحان کنید.\n";
        }
    }

    return 0;
}
