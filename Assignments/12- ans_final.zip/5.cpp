#include <iostream>
#include <fstream>
#include <string>
using namespace std;

struct Student {
    string name;
    int ID;
    int a1, a2, a3;
};

int main() {
    ifstream voroodi("students.txt");
    ofstream khorooji("averages.txt");

    Student student;
    while (voroodi >> student.name >> student.ID >> student.a1 >> student.a2 >> student.a3) {
        double average = (student.a1 + student.a2 + student.a3) / 3.0;
        khorooji << student.name << " " << student.ID << " " << average << endl;
        if (average > 17) {
            cout << "student bartar: " << student.name << " average student bartar: " << average << endl;
        }
    }
    voroodi.close();
    khorooji.close();
    return 0;
}
