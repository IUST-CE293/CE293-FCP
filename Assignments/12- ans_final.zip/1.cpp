#include <iostream>
using namespace std;
int func(int arr[],int index,int newmax,int n){
    if(index==n)
    return newmax;
    
    else if(index==0)
    return func(arr,1,arr[0],n);
    
    if(arr[index]>newmax)
    return func(arr,index+1,arr[index],n);
    else
    return func(arr,index+1,newmax,n);
}
int main(){
    int n;
    cin>>n;
    int arr[n];
    for(int i=0;i<n;i++)
    {
    cin>>arr[i];
    }
    cout<<func(arr,0,0,n);
    return 0;
}