#include <iostream>
using namespace std;

int main()
{
    char input[100];
    cin.get ( input , 100 );
    char r[100] = {0};
    int n1 = 0;
    int n2 = 1;
    r[0] = input[0];
    int q[100];
    int q1 = 0;
    while ( input[n1] != '\0' )
    {
        bool repeat = false;
        for ( int i = 0 ; i < n2 ; i++ )
        {
            if ( input[n1] == r[i] )
            {
                repeat = true;
                break;
            }
        }
        if ( !repeat )
        {
            r[n2] = input[n1];
            n2 ++;
        }
        else
        {
            q[q1] = n1;
            q1 ++;
        }
        n1 ++;
    }
    cout << r;
    int max = n1 - q[q1 - 1];
    for ( int i = 0 ; i < q1 - 1 ; i++ )
    {
        if ( q[i + 1] - q[i] > max ) max = q[i + 1] - q[i];
    }
    cout << endl << max;
    return 0;
}