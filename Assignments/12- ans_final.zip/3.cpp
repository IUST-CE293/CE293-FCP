#include <iostream>
using namespace std;
int main(){
    int n;
    cin>>n;
    int* arr=new int[n];
    int* result=new int[n];
    for(int i=0;i<n;i++)
    {
    cin>>*(arr+i);
    }
    for(int i=0;i<n;i++)
    {
    cout<<*(arr+i)<<" ";
    }
    cout<<endl;
    for(int i=0;i<n;i++)
    {
        *(result+i)=*(arr+n-1-i);
    }
    int min=*(arr);
    int index=0;
    for(int i=0;i<n;i++)
    {
       if(*(arr+i)<min)
       {
        min=*(arr+i);
       }
    }
    for(int i=0;i<n;i++)
    {
      cout<<*(result+i)<<" ";
    }
    cout<<endl;
    cout<<min<<" ";
    for(int i=0;i<n;i++)
    {
        if(min==*(arr+i))
        cout<<i<<" ";
    }
    return 0;
}