#include <iostream>
#include <queue>
#include <string>
#include <vector>
#include <algorithm>
using namespace std;

class Node {
public:
    int value;
    Node* left;
    Node* right;

    Node(int val) {
        value = val;
        left = nullptr;
        right = nullptr;
    }
};


Node* buildTree(const vector<string>& levelOrder) {
    if (levelOrder.empty() || levelOrder[0] == "*")
        return nullptr;

    Node* root = new Node(stoi(levelOrder[0]));
    queue<Node*> q;
    q.push(root);

    int i = 1;
    while (i < levelOrder.size()) {
        Node* current = q.front();
        q.pop();

        if (levelOrder[i] != "*") {
            current->left = new Node(stoi(levelOrder[i]));
            q.push(current->left);
        }
        i++;

        if (i < levelOrder.size() && levelOrder[i] != "*") {
            current->right = new Node(stoi(levelOrder[i]));
            q.push(current->right);
        }
        i++;
    }

    return root;
}

int height(Node* root) {
    if (root == nullptr) {
        return 0;
    }
    int leftHeight = height(root->left);
    int rightHeight = height(root->right);
    return 1 + max(leftHeight, rightHeight);
}

int width(Node* root) {
    if (root == nullptr) {
        return 0;
    }

    queue<Node*> q;
    q.push(root);
    int maxWidth = 0;

    while (!q.empty()) {
        int levelSize = q.size();
        maxWidth = max(maxWidth, levelSize);

        for (int i = 0; i < levelSize; i++) {
            Node* current = q.front();
            q.pop();
            if (current->left)
                q.push(current->left);
            if (current->right)
                q.push(current->right);
        }
    }

    return maxWidth;
}

int main() {
    string input;
    getline(cin, input);  

    vector<string> levelOrder;
    string temp = "";
    for (char ch : input) {
        if (ch == ',') {
            levelOrder.push_back(temp);
            temp = "";  
        } else {
            temp += ch; 
        }
    }
    if (!temp.empty()) {
        levelOrder.push_back(temp);  
    }

    Node* root = buildTree(levelOrder);

    int treeHeight = height(root);
    int treeWidth = width(root);

    
    cout << treeHeight << endl;
    cout << treeWidth << endl;

    return 0;
}
