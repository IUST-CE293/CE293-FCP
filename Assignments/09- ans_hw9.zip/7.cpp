#include <iostream>
#include<string>
using namespace std;
int main()
{
  string str;
  getline(cin,str);
  for(size_t i=0;i<str.length();i++)
  {
      if(int(str[i])!=32 && str[i]!='z')
        cout<<char(int(str[i])+1);
        else if(str[i]=='z')
        cout<<'a';
      else 
      cout<<str[i];
  }
    return 0;
} 