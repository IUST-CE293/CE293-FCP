#include <iostream>
#include <string>
using namespace std;

int main() 
{
    string s;
    cin >> s;

    int n = s.size();
    int left = 0 , right = 0;  
    int max = 0;     
    string longest = ""; 
    int seen[200] = {0}; 

    while (right < n) 
    {
        if (seen[s[right]] == 0) 
        {
            
            seen[s[right]] = 1;
            right++;
            
            if (right - left > max) 
            {
                max = right - left;
                longest = s.substr(left, max);
            }
        } 
        else 
        {
            
            seen[s[left]] = 0;
            left++;
        }
    }

  
    cout << longest << endl;

    return 0;
}
