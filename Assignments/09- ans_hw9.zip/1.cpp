#include <iostream>
using namespace std;
int main()
{
    string str,result="";
    getline(cin,str);
    int counter=1;
    for(size_t i=1;i<=str.size();i++)
    {
        if(i<str.size() && str[i]==str[i-1])
        {
            counter++;
        }
        else 
        {
            result+=str[i-1];
            result+=to_string(counter);
            counter=1;
        }
    }
    
    cout<<result;
    return 0;
}