#include <iostream>
#include<string>
#include <algorithm>
using namespace std;
int main()
{
    string first,second,result="";
    getline(cin,first);
    getline(cin,second);
    size_t m=max(first.length(),second.length());
    for(size_t i=0;i<m;i++)
    {
        if(i<first.length())
        cout<<first[i];
        if(i<second.length())
        cout<<second[i];
    }
    return 0;
} 