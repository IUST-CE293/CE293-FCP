#include <iostream>
#include <queue>
#include <string>
#include <vector>
using namespace std;

class Node {
public:
    int value;
    Node* left;
    Node* right;

    Node(int val) {
        value = val;
        left = nullptr;
        right = nullptr;
    }
};

Node* insert(Node* root, int value) {
    if (root == nullptr) {
        return new Node(value);
    }
    if (value < root->value) {
        root->left = insert(root->left, value);
    } else {
        root->right = insert(root->right, value);
    }
    return root;
}

Node* buildTree(const vector<string>& levelOrder) {
    if (levelOrder.empty() || levelOrder[0] == "*")
        return nullptr;

    Node* root = nullptr;
    for (const string& val : levelOrder) {
        if (val != "*") {
            root = insert(root, stoi(val));
        }
    }
    return root;
}

void inOrder(Node* root, vector<int>& result) {
    if (root == nullptr) {
        return;
    }
    inOrder(root->left, result);
    result.push_back(root->value);
    inOrder(root->right, result);
}

int main() {
    string input;
    getline(cin, input);

    vector<string> levelOrder;
    string temp = "";
    for (char ch : input) {
        if (ch == ',') {
            levelOrder.push_back(temp);
            temp = "";
        } else {
            temp += ch;
        }
    }
    if (!temp.empty()) {
        levelOrder.push_back(temp);
    }

    Node* root = buildTree(levelOrder);

    vector<int> result;
    inOrder(root, result);

    for (int val : result) {
        cout << val << " ";
    }
    cout << endl;

    return 0;
}
