#include <iostream>
#include <string>
using namespace std ;


long long j = 1 ;


long long Fibonachi ( long long number )
{
    long long a0 = 0 , a1 = 1 , a2 = 1 ;
    for ( int i = 2 ; i <= number ; i++ )
    {
        a2 = a1 + a0 ; 
        a0 = a1 ;
        a1 = a2 ; 
    }
    return a0 ;
}



long long FibInverse ( long long number )
{
    while ( Fibonachi (j) != number )
    j++ ; 
    return j ; 
}



int main ()
{ 
    string input ; 
    getline ( cin , input ) ; 
    input += " " ;
    long long len = input.length() ; 
    for ( long long i = 0 ; i < len ; i++ )
    {
        if ( input[i] == ' ' )
        {
            continue ;
        } 
        string value1 = "" ;
        value1 += input[i] ;
        while ( input[i+1] != ' ' ) 
        {
            value1 += input[i+1] ;
            i++ ; 
        }
        cout << FibInverse ( stoll ( value1 ) ) << ' ' ;  
    }
}