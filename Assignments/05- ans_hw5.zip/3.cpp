#include <iostream>
#include <cmath> 
using namespace std ;


void NumberOfDigits ( string number )
{
    long long len = number.length() , i ;
    if ( number[0] == '-' || number[0] == '+' )
    {
    len-- ;
    number = number.substr(1) ;
    }
    for ( i = 0 ; number[i] == '0' ; i++ )
    len-- ;
    cout << len << endl ;   
}


void NthDigit ( string number , long long number2 )
{ 
    long long len = number.length() ;
    len = len - number2 ; 
    string answer = number.substr(len,1) ;
    cout << answer << endl ; 
}


void SignedOrNot ( string number )
{
    if ( number[0] == '-' || number[0] == '+' )
    cout << "signed " ;
    else
    cout << "unsigned " ;
}

void EvenOrOdd ( string number )
{
    long long len = number.length() ;
    string answer = "" ;
    switch ( number [len-1] )
    {
        case '0' : answer = "even" ; break ;
        case '2' : answer = "even" ; break ;
        case '4' : answer = "even" ; break ;
        case '6' : answer = "even" ; break ;
        case '8' : answer = "even" ; break ;
        default : answer = "odd" ; break ;
    }
    cout << answer ; 
}


int main ()
{
    string number ; 
    cin >> number ; 
    long long number2 ;
    cin >> number2 ;
    NumberOfDigits(number) ;
    NthDigit(number,number2) ;
    SignedOrNot(number) ;
    EvenOrOdd(number) ; 
    return 0 ; 
}