#include <iostream> 
#include <string>
using namespace std ; 


long long NumberOfWords ( string input , long long length1 )
{
    int counter = 0 ;
    for ( int i = 0 ; i < length1 ; i++ )
    {
        if ( input[i] != ' ' && input[i+1] == ' ' )
        {
            counter++ ; 
        }
    }
    if ( input[length1-1] != ' ' )
    counter++ ; 
    return counter ; 
}



int main ()
{
    string input ;
    getline ( cin , input ) ; 
    long long length1 = input.length() ;
    cout << NumberOfWords( input , length1 ) ;
    return 0 ;
}