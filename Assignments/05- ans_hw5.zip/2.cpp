// {n} == number of characters in this form.
// * == any number of digits allowed . 
// + == at least should be used once . 
// ? == 0 or 1 times . 
// {n,} == n or more times . 
// {y,z} == at least y times , less than z times .
// ^ to find a line starting with the following expression ;
// $ to find a line starting with the expression mentioned before ;
// [abc] a , b or c ;
// [^abc] anything except a , b and c ; 
// [a-z] a to z ;
// [A-Z] A to Z ;
// [a-zA-Z] a to z but not case sensitive ;
// [0-9] 0 to 9 === \d  // \D === [^0-9] ; 
// [a-zA-Z0-9] === \w ;
// \W === ^\w ;
// .. : any two things ;



#include <regex> 
#include <iostream>
#include <string>
using namespace std ; 



void Function1 ( bool input )
{
    cout << "The argument must not be a float" ;
}



string Function1 ( string input )
{ 
    long long lengthstr = input.length() ; 
    for ( int i = 0 ; i < ( lengthstr / 2 ) + ( lengthstr % 2 ) ; i++ )
    {
        int j = lengthstr - 1 - i ;
        if ( i != j )
        {
            swap ( input [i] , input [j] ) ;
        }
    }
    return input ; 
}



void Function1 ( long long number )
{
    long long sum = 0 , number1 ;
    for ( int i = 0 ; i < number ; i++ )
    {
        cin >> number1 ; 
        sum += number1 ;
    }
    cout << sum ; 
}



int main ()
{
    string input ;
    getline ( cin , input ) ; 
    regex searchvalue1("[0-9]+\\.{1}[0-9]+") ; 
    // regex searchvalue2("[0-9]+") ;
    regex searchvalue3 ("[^-]*.*[a-zA-Z]+.*") ;
    if ( regex_match ( input , searchvalue1 ) )
    {
        bool isfloat = true ; 
        Function1 ( isfloat ) ;
    }
    // else if ( regex_match ( input , searchvalue2 ) ) 
    // {
    //     Function1(stoll(input)) ;
    // }
    else if ( regex_match ( input , searchvalue3 ) ) 
    cout << Function1 ( input ) ;
    else
    {
        long long number = stoll ( input ) ;
        if ( number < 0 )
        {
            cout << "error" ;
        }
        else
        Function1(number) ;
    }

    return 0 ;
}