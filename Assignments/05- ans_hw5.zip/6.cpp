#include <iostream>
using namespace std ; 


long long Tavan2 ( long long number )
{
    long long counter = 0 ;
    while ( number % 2 == 0 )
    {
        counter ++ ;
        number /= 2 ;
    }
    return counter ; 
}


long long Tavan3 ( long long number )
{
    long long counter = 0 ;
    while ( number % 3 == 0 )
    {
        counter ++ ;
        number /= 3 ;
    }
    return counter ; 
}


long long Tavan5 ( long long number )
{
    long long counter = 0 ;
    while ( number % 5 == 0 )
    {
        counter ++ ;
        number /= 5 ;
    }
    return counter ; 
}



int main ()
{
    long long number ; 
    cin >> number ; 
    cout << Tavan2(number) << ' ' << Tavan3(number) << ' ' << Tavan5(number) ; 
    return 0 ;
}