#include <iostream>
#include <fstream>
#include <string>
#include <cctype>

// تابع رمزنگاری سزار
std::string encrypt_password(const std::string& plain_text) {
    std::string encrypted_text;

    if (plain_text[0] > 80) {
        encrypted_text = "abc";
        for (char c : plain_text) {
            encrypted_text += char(c - 5);  // شیفت سزار -5
        }
        encrypted_text += "x502";
    } else {
        encrypted_text = "bd";
        for (char c : plain_text) {
            encrypted_text += char(c + 9);  // شیفت سزار +9
        }
        encrypted_text += "f103";
    }

    return encrypted_text;
}

// تابع رمزگشایی رمز عبور
std::string decrypt_password(const std::string& cipher_text) {
    std::string decrypted_text;

    if (cipher_text.substr(0, 3) == "abc") {
        for (size_t i = 3; i < cipher_text.size() - 4; ++i) {
            decrypted_text += char(cipher_text[i] + 5);
        }
    } else if (cipher_text.substr(0, 2) == "bd") {
        for (size_t i = 2; i < cipher_text.size() - 4; ++i) {
            decrypted_text += char(cipher_text[i] - 9);
        }
    }

    return decrypted_text;
}

// ثبت نام کاربر جدید
void sign_up() {
    std::string username, password;

    //std::cout << "Enter username: ";
    std::cin >> username;
    //std::cout << "Enter password: ";
    std::cin >> password;

    std::string encrypted_password = encrypt_password(password);

    std::ofstream file("users.csv", std::ios::app);
    if (file.is_open()) {
        file << username << "," << encrypted_password << "\n";
        file.close();
        std::cout << "User signed up successfully!\n";
    } else {
        std::cout << "Error opening file!\n";
    }
}

// ورود کاربر
bool sign_in(std::string& username, bool cond) {
    std::string input_username, input_password;
    //std::cout << "Enter username: ";
    std::cin >> input_username;
    //std::cout << "Enter password: ";
    std::cin >> input_password;

    std::ifstream file("users.csv");
    std::string line, file_username, file_password;
    if (file.is_open()) {
        while (getline(file, line)) {
            size_t comma_pos = line.find(',');
            file_username = line.substr(0, comma_pos);
            file_password = line.substr(comma_pos + 1);

            if (file_username == input_username && decrypt_password(file_password) == input_password) {
                username = file_username;
                if(cond)
                    std::cout << "Sign in successful!\n";
                return true;
            }
        }
        file.close();
    }
    std::cout << "Invalid username or password.\n";
    return false;
}

// تغییر رمز عبور
void change_password(const std::string& username) {
    std::string new_password;
    //std::cout << "Enter new password: ";
    std::cin >> new_password;

    std::ifstream file("users.csv");
    std::ofstream temp_file("temp.csv");
    std::string line, file_username, file_password;

    if (file.is_open() && temp_file.is_open()) {
        while (getline(file, line)) {
            size_t comma_pos = line.find(',');
            file_username = line.substr(0, comma_pos);
            file_password = line.substr(comma_pos + 1);

            if (file_username == username) {
                temp_file << file_username << "," << encrypt_password(new_password) << "\n";
            } else {
                temp_file << line << "\n";
            }
        }
        file.close();
        temp_file.close();

        remove("users.csv");
        rename("temp.csv", "users.csv");
        std::cout << "Password changed successfully!\n";
    } else {
        std::cout << "Error opening file!\n";
    }
}

// بازیابی رمز عبور
void forgot_password(const std::string& username) {
    std::ifstream file("users.csv");
    std::string line, file_username, file_password;

    if (file.is_open()) {
        while (getline(file, line)) {
            size_t comma_pos = line.find(',');
            file_username = line.substr(0, comma_pos);
            file_password = line.substr(comma_pos + 1);

            if (file_username == username) {
                std::cout << "Your password is: " << decrypt_password(file_password) << "\n";
                return;
            }
        }
        file.close();
    }
    std::cout << "Username not found.\n";
}
void gozaresh(){
    std::ifstream file("users.csv");
    std::string line, file_username, file_password;

    if (file.is_open()) {
        while (getline(file, line)) {
            size_t comma_pos = line.find(',');
            file_username = line.substr(0, comma_pos);
            file_password = line.substr(comma_pos + 1);
            std::cout << file_username << "\n" << file_password << "\n";
        }
        file.close();
    }
}
// منوی اصلی
int main() {
    int choice,option;
    std::string username;

    //std::cout << "1- Sign up\n2- Sign in\n3- gozaresh\nChoose an option: ";
    std::cin >> choice;

    if (choice == 1) {
        sign_up();
    } else if (choice == 2) {
        //std::cout << "1- Change password\n2- Forgot your password\n3- none\nChoose an option: ";
        int option;
        std::cin >> option;
        if (option == 3) {
            return sign_in(username,true);
        }
        if (sign_in(username,false)) {
            
            if (option == 1) {
                change_password(username);
            } else if (option == 2) {
                forgot_password(username);
            }
        }
    }else if (choice == 3) {
        gozaresh();
    }

    return 0;
}
