#include <iostream>
using namespace std;
int main()
{
    long a1,a2,a3,n,sum,g;
    a1 = a2 = a3 = 1;
    cin >> n;

    if (n==1 || n==2 || n==3)
        cout << 1;
    else if (n==4)
        cout << 3;
    else if (n>4)
    {
    for (int i=1;i<=n-4;i++)
    {
        g = a3;
        a3 = a1 + a2 + g;
        a1 = a2;
        a2 = g;
        sum = a1 + a2 + a3;
    }
    cout << sum;
    }
}