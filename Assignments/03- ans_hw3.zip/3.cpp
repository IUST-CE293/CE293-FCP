#include<iostream>
#include<cmath>
using namespace std;

long long powerto(long x, int y){
    long long ans=1;
    for(int i=0; i<y; i++){
        ans*=x;
    }
    return ans;
}
int main()
{
    long long a1,a1_copy,a2,a2_copy,c,n1=0,n2=0,f=0;
    cin>>a1;
    cin>>a2;
    a1_copy=a1;
    a2_copy=a2;
    while(a1_copy!=0){
        n1++;
        a1_copy/=10;
    }
    while(a2_copy!=0){
        n2++;
        a2_copy/=10;
    }
    c=(a1/powerto(10,n1-1));
    c*=powerto(10,n1-1);
    for(int i=1 ; i<=n1-1 ; i+=2){
        f+=(a1%10)*powerto(10,i);
        a1/=10;
        f+=(a1%10)*powerto(10,i-1);
        a1/=10;
    }
    for(int i=1 ; i<=n2 ; i++){
        a1=a2%10;
        a2/=10;
        a2_copy+=a1*powerto(10,(n2-i)); 
    }
    if(n1%2){
        f+=c;
        cout<<f<<endl<<a2_copy;
    }else{cout<<f<<endl<<a2_copy;}
    return 0;
}