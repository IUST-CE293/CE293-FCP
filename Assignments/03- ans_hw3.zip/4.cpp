#include <iostream>
#include <string>
#include <cctype>

enum Functions { FUNC1, FUNC22, NOT_DEFINED };
 
// تابع برای بازگرداندن کد تابع با توجه به نام
Functions get_function_code(const std::string& task) {
    if (task == "Func1") return FUNC1;
    if (task == "Func22") return FUNC22;
    return NOT_DEFINED;
}

// تابع بازگشتی برای تبدیل رشته به عدد صحیح
int val_returned(const std::string& num) {
    int sum = 0;
    for (char c : num) {
        if (isdigit(c)) {
            sum = sum * 10 + (c - '0');
        } else {
            break;
        }
    }
    return sum;
}

// نمونه‌ای از توابع Func1 و Func22
int func1(int number) {
    return number * 2; // به عنوان مثال، عدد را دو برابر می‌کند
}

int func22(int number) {
    return number + 10; // به عنوان مثال، 10 به عدد اضافه می‌کند
}

// تابعی برای بررسی و فراخوانی تابع مناسب
void switch_code(const std::string& task, int number) {
    switch (get_function_code(task)) {
        case FUNC1:
            std::cout << "Result from Func1: " << func1(number) << "\n";
            break;
        case FUNC22:
            std::cout << "Result from Func22: " << func22(number) << "\n";
            break;
        default:
            std::cout << "Exception: not defined function\n";
    }
}

int main() {
    std::string temp_code;
    std::getline(std::cin, temp_code);

    // استخراج نام تابع و عدد
    std::string task;
    int i = 0;

    // استخراج نام تابع تا رسیدن به فاصله
    while (i < temp_code.size() && temp_code[i] != ' ') {
        task += temp_code[i++];
    }

    // استخراج بخش عددی از رشته
    int number = val_returned(temp_code.substr(i + 1));

    // فراخوانی تابع مناسب
    switch_code(task, number);

    return 0;
}
