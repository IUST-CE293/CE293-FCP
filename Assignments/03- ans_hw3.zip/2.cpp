#include <iostream>
using namespace std;
int main()
{
    char a;
    int b,i,j;
    cin>>a>>b;
    if (a=='A')
        for (i=0;i<b;i++)
            {
                for(j=1;j<b-i;j++)
                    cout<<" ";
                cout<<"*";
                if (i==0)
                {
                    for(j=1;j<b;j++)
                    cout<<" ";
                }
                else if(i==b/2)
                {
                    for(j=1;j<=(i*2)-1;j++)
                        cout<<"*";
                    cout<<"*";
                    for(j=1;j<b;j++)
                    cout<<" ";
                }
                else
                {
                    for(j=1;j<=(i*2)-1;j++)
                        cout<<" ";
                    cout<<"*";
                    for(j=1;j<b;j++)
                    cout<<" ";
                }
                cout<<endl;
            }
    else if (a=='B')
        for (i=1;i<=b;i++)
            {
                if (i==1 || i==b/2+1 || i==b)
                {
                    for (j=1;j<=(b/2)+1;j++)
                        cout<<"*";
                    cout<<" ";
                }
                else
                {
                    cout<<"*";
                    for (j=1;j<=b/2;j++)
                        cout<<" ";
                    cout<<"*";
                }
                cout<<endl;      
            }
    else if(a=='C')
        for (i=1;i<=b;i++)
            {
                if (i==1 || i==b)
                {
                    cout<<" ";
                    for (j=1;j<=(b/2)+1;j++)
                        cout<<"*";
                    cout<<" ";
                }
                else if (i==2 || i==b-1)
                {
                    cout<<"*";
                    for (j=1;j<=(b/2)+1;j++)
                        cout<<" ";
                    cout<<"*";
                }
                else
                {
                    cout<<"*";
                    for (j=1;j<=(b/2)+2;j++)
                        cout<<" ";
                }
                cout<<endl;
            }
    else if (a=='D')
        for (i=1;i<=b;i++)
            {
                if (i==1 || i==b)
                {
                    for (j=1;j<=(b/2)+1;j++)
                        cout<<"*";
                    cout<<" ";
                }
                else
                {
                    cout<<"*";
                    for (j=1;j<=(b/2);j++)
                        cout<<" ";
                    cout<<"*";
                }
                cout<<endl;
            }
    else if (a=='E')
        for (i=1;i<=b;i++)
            {
                if (i==1 || i==b)
                {
                    for (j=1;j<b;j++)
                        cout<<"*";
                }
                else if (i==(b/2)+1)
                {
                    for (j=1;j<b-1;j++)
                        cout<<"*";
                    cout<<" ";
                }
                else
                {
                    cout<<"*";
                    for (j=1;j<b-1;j++)
                        cout<<" ";
                }
                cout<<endl;
            }
    else if (a=='F')
        for (i=1;i<=b;i++)
            {
                if (i==1)
                {
                    for (j=1;j<b;j++)
                        cout<<"*";
                }
                else if (i==(b/2)+1)
                {
                    for (j=1;j<b-1;j++)
                        cout<<"*";
                    cout<<" ";
                }
                else
                {
                    cout<<"*";
                    for (j=1;j<=b-2;j++)
                        cout<<" ";
                }
                cout<<endl;
            }
    else if (a=='G')
        for (i=1;i<=b;i++)
            {
                if (i==1 || i==b)
                {
                    cout<<" ";
                    for (j=1;j<=(b/2);j++)
                        cout<<"*";
                    cout<<" ";
                }
                else if (i==(b/2)+1)
                {
                    cout<<"* ";
                    for (j=1;j<=(b/2);j++)
                        cout<<"*";
                }
                else if (i>1 && i<(b/2))
                {
                    cout<<"*";
                    for (j=1;j<=(b/2);j++)
                        cout<<" ";
                    cout<<"*";
                }
                else if (i==(b/2))
                {
                    cout<<"*";
                    for (j=1;j<=(b/2)+1;j++)
                        cout<<" ";
                }
                else
                {
                    cout<<"*";
                    for (j=1;j<=(b/2);j++)
                        cout<<" ";
                    cout<<"*";
                }
                cout<<endl;
            }
    else if (a=='H')
        for (i=1;i<=b;i++)
            {
                if (i==(b/2)+1)
                {
                    for (j=1;j<=(b/2)+3;j++)
                        cout<<"*";
                }
                else
                {
                    cout<<"*";
                    for (j=1;j<=(b/2)+1;j++)
                        cout<<" ";
                    cout<<"*";
                }
                cout<<endl;
            }
    else if (a=='I')
        for (i=1;i<=b;i++)
            {
                if (i==1 || i==b)
                {
                    for (j=1;j<=b-2;j++)
                        cout<<"*";
                }
                else
                {
                    for (j=1;j<=(b/2)-1;j++)
                        cout<<" ";
                    cout<<"*";
                    for (j=1;j<=(b/2)-1;j++)
                        cout<<" ";
                }
                cout<<endl;
            }
    else if (a=='J')
        for (i=1;i<=b;i++)
            {
                if (i==1)
                {
                    cout<<" ";
                    for (j=1;j<=(b/2)+2;j++)
                        cout<<"*";
                }
                else if (i>1 && i<b-1)
                {
                    for (j=1;j<=(b/2)+1;j++)
                        cout<<" ";
                    cout<<"* ";
                }
                else if (i==b-1)
                {
                    cout<<"*";
                    for (j=1;j<=(b/2);j++)
                        cout<<" ";
                    cout<<"* ";
                }
                else
                {
                    cout<<" ";
                    for (j=1;j<=(b/2);j++)
                        cout<<"*";
                    cout<<"  ";
                }
                cout<<endl;
            }
    else if (a=='K')
        for (i=1;i<=b;i++)
            {
                if (i<=(b/2))
                {
                    cout<<"*";
                    for (j=1;j<=b-2*(i);j++)
                        cout<<" ";
                    cout<<"*";
                }
                else
                {
                    cout<<"*";
                    for (j=1;j<=(b%2)+2*(i-((b/2)+1));j++)
                        cout<<" ";
                    cout<<"*";
                }
            cout<<endl;
            }
    else if (a=='L')
        for (i=1;i<=b;i++)
            {
                if (i==b)
                {
                    for (j=1;j<=b;j++)
                        cout<<"*";
                }
                else
                    cout<<"* ";
                cout<<endl;
            }
    else
        for (i=1;i<=b;i++)
            {
                if (i==1 || i==2)
                {
                    cout<<"**";
                    for (j=1;j<=(2*b)-4;j++)
                        cout<<" ";
                    cout<<"**";
                }
                else
                {
                    cout<<"*";
                    for (j=1;j<=i-2;j++)
                        cout<<" ";
                    cout<<"*";
                    for (j=1;j<=2*(b-i);j++)
                        cout<<" ";
                    cout<<"*";
                    for (j=1;j<=i-2;j++)
                        cout<<" ";
                    cout<<"*";
                }
                cout<<endl;
            }
    return 0;
}