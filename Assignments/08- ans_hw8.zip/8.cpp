#include <iostream>
#include <string>
#include <vector>
#include <map>
using namespace std;

// Structure to store plane information
struct Plane {
    string id;
    int status;  // 1: in airport, 2: taking off, 3: landing, 4: not in airport
    int runway;  // -1 if not on any runway
    
    Plane(const string& _id = "", int _status = 4, int _runway = -1) 
        : id(_id), status(_status), runway(_runway) {}
};

// Structure to store runway information
struct Runway {
    bool occupied;
    string plane_id;
    
    Runway() : occupied(false), plane_id("") {}
};

// Global variables
vector<Plane> planes;
vector<Runway> runways;

// Function to find plane by ID
Plane* find_plane(const string& id) {
    for (auto& plane : planes) {
        if (plane.id == id) {
            return &plane;
        }
    }
    // If not found, create new plane with status 4
    planes.emplace_back(id, 4, -1);
    return &planes.back();
}

// Function to find first free runway
int find_first_free_runway() {
    for (int i = 0; i < runways.size(); i++) {
        if (!runways[i].occupied) {
            return i;
        }
    }
    return -1;
}

// Function to find last free runway
int find_last_free_runway() {
    for (int i = runways.size() - 1; i >= 0; i--) {
        if (!runways[i].occupied) {
            return i;
        }
    }
    return -1;
}

// Command functions
void take_off(const string& id) {
    Plane* plane = find_plane(id);
    
    if (plane->status == 4) {
        cout << "YOU ARE NOT HERE\n";
        return;
    }
    if (plane->status == 3) {
        cout << "YOU ARE LANDING NOW\n";
        return;
    }
    if (plane->status == 2) {
        cout << "YOU ARE TAKING OFF\n";
        return;
    }
    
    int runway = find_first_free_runway();
    if (runway == -1) {
        cout << "NO FREE BOUND\n";
        return;
    }
    
    plane->status = 2;
    plane->runway = runway;
    runways[runway].occupied = true;
    runways[runway].plane_id = plane->id;
}

void landing(const string& id) {
    Plane* plane = find_plane(id);
    
    if (plane->status == 1) {
        cout << "YOU ARE HERE\n";
        return;
    }
    if (plane->status == 2) {
        cout << "YOU ARE TAKING OFF\n";
        return;
    }
    if (plane->status == 3) {
        cout << "YOU ARE LANDING NOW\n";
        return;
    }
    
    int runway = find_last_free_runway();
    if (runway == -1) {
        cout << "NO FREE BOUND\n";
        return;
    }
    
    plane->status = 3;
    plane->runway = runway;
    runways[runway].occupied = true;
    runways[runway].plane_id = plane->id;
}

void plane_status(const string& id) {
    Plane* plane = find_plane(id);
    cout << plane->status << "\n";
}

void band_status(const string& runway_str) {
    int runway_num = stoi(runway_str) - 1;
    if (runways[runway_num].occupied) {
        cout << runways[runway_num].plane_id << "\n";
    } else {
        cout << "FREE\n";
    }
}

// Function pointer type for commands
typedef void (*CommandFunc)(const string&);

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    
    int n, k;
    cin >> n >> k;
    
    // Initialize runways
    runways.resize(k);
    
    // Read initial planes
    string id;
    for (int i = 0; i < n; i++) {
        cin >> id;
        planes.emplace_back(id, 1, -1);
    }
    
    // Command handling
    int q;
    cin >> q;
    
    // Map of function pointers for commands
    map<char, CommandFunc> command_funcs;
    command_funcs['T'] = take_off;
    command_funcs['L'] = landing;
    command_funcs['P'] = plane_status;
    command_funcs['B'] = band_status;
    
    string command;
    string param;
    for (int i = 0; i < q; i++) {
        cin >> command >> param;
        command_funcs[command[0]](param);
    }
    
    return 0;
}