#include <stdio.h>
#include <malloc.h>

int coefficients(int *initialCoefficients, int m, int *w, int k) {
    int i, j, counter = 0;
    int *z = (int*)malloc(10000*sizeof(int));
    for(i = 0; i < m; i++) {
        counter = i;
        for(j = 0; j < k; j++) {
            *(z + counter) += *(initialCoefficients + i) * *(w + j);
            ++counter;
        }
    }
    for(i = 0; i < m + k + 1; i++) {
        *(w + i) = *(z + i);
    }
    return counter;
}

int main() {
    int *initialCoefficients = (int*)malloc(10000*sizeof(int));
    int *b = (int*)malloc(10000*sizeof(int));
    int m, n, j, i, k;
    scanf("%d %d", &m, &n);
    m++;
    k = m;
    for(j = 0; j < m; j++) {
        scanf("%d", (initialCoefficients + j));
        *(b + j) = *(initialCoefficients + j);
    }
    for(i = 0; i < n - 1; i++) {
        k = coefficients(initialCoefficients, m, b, k);
    }
    for(j = 0; j < k; j++) {
        printf("%d ", *(b + j));
    }
    return 0;
}

