#include <iostream>
#include <string>
using namespace std;

void Seprates_Number(int Number, int *ReversedNumber) {
    // متغیر را مقداردهی اولیه می‌کنیم
    *ReversedNumber = 0;
    while (Number > 0) {
        // رقم آخر عدد را به عدد معکوس اضافه می‌کنیم
        *ReversedNumber = *ReversedNumber * 10 + (Number % 10);
        // رقم آخر را حذف می‌کنیم
        Number /= 10;
    }
}

string Check(int Number, int *ReversedNumber) {
    // اگر عدد اولیه برابر عدد معکوس باشد
    if (Number == *ReversedNumber) {
        return "YES";
    } else {
        return "NO";
    }
}

int main() {
    int Number;
    cin >> Number; // عدد ورودی

    int ReversedNumber = 0;
    // فراخوانی تابع برای ساخت عدد معکوس
    Seprates_Number(Number, &ReversedNumber);

    // بررسی و چاپ نتیجه
    cout << Check(Number, &ReversedNumber) << endl;

    return 0;
}
