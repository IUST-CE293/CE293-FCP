#include <iostream>
#include <cstdlib>
#include <cstring>

using namespace std;

int main() {
    // تخصیص پوینترها برای ذخیره اعداد و نتیجه
    char* number1 = (char*)malloc(12345 * sizeof(char));
    char* number2 = (char*)malloc(12345 * sizeof(char));
    char* sum = (char*)malloc((12345 + 1) * sizeof(char));

    int n;
    cin >> n;

    // خواندن ورودی‌ها
    cin >> number1;
    cin >> number2;

    int str1 = strlen(number1) - 1;
    int str2 = strlen(number2) - 1;
    int max = (str1 > str2) ? str1 : str2;
    int carry = 0;

    for (int counter = max; counter >= 0; counter--) {
        // اگر یکی از اعداد تمام شود، به جای آن صفر قرار می‌دهیم
        char digit1 = (str1 >= 0) ? *(number1 + str1) : '0';
        char digit2 = (str2 >= 0) ? *(number2 + str2) : '0';

        int current_sum = carry + (digit1 - '0') + (digit2 - '0');
        *(sum + counter) = (current_sum % n) + '0'; // ذخیره رقم نتیجه به صورت کاراکتر
        carry = current_sum / n; // محاسبه انتقال

        str1--;
        str2--;
    }

    // اگر انتقال باقی مانده باشد، در ابتدای عدد قرار می‌گیرد
    if (carry > 0) {
        cout << carry;
    }

    // چاپ نتیجه
    for (int counter = 0; counter <= max; counter++) {
        cout << *(sum + counter);
    }

    // آزادسازی حافظه
    free(number1);
    free(number2);
    free(sum);

    return 0;
}

