#include <iostream>
#include <stack>
#include <string>
#include <functional>
#include <cmath>
using namespace std;

// Function pointer array
using operation = function<int(int, int)>;
operation ops[256];

// Operator precedence
int precedence(char op) {
    if (op == '^') return 3;
    if (op == '*' || op == '/') return 2;
    if (op == '+' || op == '-') return 1;
    return 0;
}

// Check if the operator is right-associative
bool isRightAssociative(char op) {
    return op == '^';
}

// Apply operation
int applyOp(int a, int b, char op) {
    return ops[op](a, b);
}

// Evaluate the expression
int evaluate(const string &s) {
    stack<int> values;
    stack<char> operators;

    for (size_t i = 0; i < s.length(); i++) {
        if (isspace(s[i])) continue;

        // If the current character is a number
        if (isdigit(s[i])) {
            int val = 0;
            while (i < s.length() && isdigit(s[i])) {
                val = val * 10 + (s[i] - '0');
                i++;
            }
            values.push(val);
            i--; // Adjust for the next loop iteration
        } else if (s[i] == '(') {
            operators.push(s[i]);
        } else if (s[i] == ')') {
            while (!operators.empty() && operators.top() != '(') {
                char op = operators.top(); operators.pop();
                int b = values.top(); values.pop();
                int a = values.top(); values.pop();
                values.push(applyOp(a, b, op));
            }
            operators.pop();
        } else {
            while (!operators.empty() &&
                   ((precedence(operators.top()) > precedence(s[i])) ||
                    (precedence(operators.top()) == precedence(s[i]) && !isRightAssociative(s[i])))) {
                char op = operators.top(); operators.pop();
                int b = values.top(); values.pop();
                int a = values.top(); values.pop();
                values.push(applyOp(a, b, op));
            }
            operators.push(s[i]);
        }
    }

    while (!operators.empty()) {
        char op = operators.top(); operators.pop();
        int b = values.top(); values.pop();
        int a = values.top(); values.pop();
        values.push(applyOp(a, b, op));
    }

    return values.top();
}

int main() {
    // Define operations
    ops['+'] = [](int a, int b) { return a + b; };
    ops['-'] = [](int a, int b) { return a - b; };
    ops['*'] = [](int a, int b) { return a * b; };
    ops['/'] = [](int a, int b) { return a / b; };
    ops['^'] = [](int a, int b) { return (int)pow(a, b); };

    string s;
    cin >> s;
    cout << evaluate(s) << endl;

    return 0;
}
