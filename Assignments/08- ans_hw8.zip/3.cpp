#include <iostream>
#include <cstdlib>
using namespace std;

int nonDuplicate(int* numbers, int isD, int N, int sameIndex) {
    int duplicate = 0;
    for (int i = 0; i < N; i++) {
        if (*(numbers + i) == isD && i != sameIndex) {
            duplicate++;
        }
    }
    return (duplicate == 0) ? 1 : 0;
}

int Smallest(int* numbers, int N) {
    int small = *(numbers);
    for (int i = 0; i < N; i++) {
        if (*(numbers + i) < small) {
            small = *(numbers + i);
        }
    }
    return small;
}

int main() {
    int* idNumber = (int*)calloc(3000, sizeof(int));
    int* suggestNumber = (int*)calloc(3000, sizeof(int));
    int counter = 0;

    while (true) {
        cin >> *(idNumber + counter);
        if (*(idNumber + counter) == -1) {
            break;
        }
        cin >> *(suggestNumber + counter);
        counter++;
    }

    int* arrOfNonDuplicate = (int*)calloc(counter, sizeof(int));
    int j = 0;

    for (int i = 0; i < counter; i++) {
        if (nonDuplicate(suggestNumber, *(suggestNumber + i), counter, i)) {
            *(arrOfNonDuplicate + j) = *(suggestNumber + i);
            j++;
        }
    }

    if (j == 0) {
        cout << "no one won." << endl;
        free(idNumber);
        free(suggestNumber);
        free(arrOfNonDuplicate);
        return 0;
    }

    int min = Smallest(arrOfNonDuplicate, j);

    for (int i = 0; i < counter; i++) {
        if (*(suggestNumber + i) == min) {
            if (nonDuplicate(idNumber, *(idNumber + i), counter, i) == 0) {
                cout << *(idNumber + i) << " cheated." << endl;
                break;
            } else if (nonDuplicate(idNumber, *(idNumber + i), counter, i) == 1) {
                cout << *(idNumber + i) << " won." << endl;
                break;
            }
        }
    }

  

    free(idNumber);
    free(suggestNumber);
    free(arrOfNonDuplicate);

    return 0;
}

