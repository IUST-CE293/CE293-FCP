#include <iostream>
#include <cstdlib>
using namespace std;

void swap(int* first, int* second) {
    *first ^= *second;
    *second ^= *first;
    *first ^= *second;
}

void bSort(int* arr, int size) {
    for (int i = 0; i < size - 1; i++) {
        for (int j = 0; j < size - i - 1; j++) {
            if (*(arr + j) > *(arr + j + 1)) {
                swap(arr + j, arr + j + 1);
            }
        }
    }
}

int main() {
    int n, *arr;
    cin >> n;
    arr = (int*)malloc(n * sizeof(int));
    for (int i = 0; i < n; i++) {
        cin >> *(arr + i);
    }
    bSort(arr, n);
    for (int i = 0; i < n; i++) {
        cout << *(arr + i) << " ";
    }
    free(arr);
    return 0;
}


