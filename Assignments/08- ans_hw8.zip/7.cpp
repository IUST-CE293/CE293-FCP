#include <iostream>
using namespace std;
void baghi(int* arr, int a) {
  for(int i=0;i<a;i++){
    arr[i]%=a;
  }
}
int main() 
{
    int n;
    cin>>n;
    int a[n];
    for(int i=0;i<n;i++)
      cin>>a[i];
    int max=a[0];
    for(int i=0;i<n;i++){
      if(a[i]>max)
        max=a[i];
    }
    int u[n][max];
    for(int i=0;i<n;i++){
      for(int j=0;j<a[i];j++)
        cin>>u[i][j];
      for(int j=0;j<max-a[i];j++)
        u[i][j+a[i]]=-1;
    }
    for(int i=0;i<n;i++){
      baghi(u[i],a[i]);
    }
    for(int i=n-1;i>=0;i--){
      for(int j=0;j<max;j++){
        if(u[i][j]>=0)
        cout<<u[i][j]<<' ';}
      cout<<endl;  
    }
    return 0;
}