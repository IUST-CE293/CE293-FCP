#include <iostream>
using namespace std;

bool can_jump(int n, int* nums) {
    int* pointer = nums;         // Initial pointer
    int* end_pointer = nums + n; // Pointer to memory after the last element

    cout << "Initial pointer: " << pointer << endl;

    while (pointer < end_pointer - 1) {
        int value = *pointer;
        if (value == 0) {
            cout << "Current: " << pointer << " (value: " << value << ") -> Cannot jump" << endl;
            cout << "Final pointer: " << pointer << endl;
            return false;
        }

        // Compute jump address
        int* jump_to = pointer + value;
        if (jump_to >= end_pointer) {
            jump_to = end_pointer - 1; // Cap the jump to the last valid address
        }

        cout << "Current: " << pointer << " (value: " << value << ") -> Jump to: " << jump_to << endl;
        pointer = jump_to;
    }

    cout << "Final pointer: " << pointer << endl;
    return pointer == end_pointer - 1;
}

int main() {
    int n;
    cin >> n;
    int* nums = new int[n];

    for (int i = 0; i < n; i++) {
        cin >> nums[i];
    }

    bool result = can_jump(n, nums);
    cout << (result ? "true" : "false") << endl;

    delete[] nums; // Free allocated memory
    return 0;
}