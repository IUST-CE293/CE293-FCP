#include <iostream>
using namespace std ;

int main ()
{
    int number ; 
    cin >> number ; 
    int array1[number] ;
    for ( int i = 0 ; i < number ; i++ )
    {
        cin >> array1[i] ;
    } 
    int counter = 0 ;
    for ( int i = 0 ; i < number - 1 ; i++ )
    {
        for ( int j = i + 1 ; j < number ; j++ )
        {
            if ( array1[j] < array1[i] )
            {
                counter++ ; 
            }
        }
    }
    cout << counter ; 
    return 0 ;
}
