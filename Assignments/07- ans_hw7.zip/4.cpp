#include <iostream>
using namespace std ; 

int main ()
{
    int number1 , number2 , number3 , counter , numberofanswers = 0 ;
    cin >> number1 ; 
    int array1[number1] ;
    for ( int i = 0 ; i < number1 ; i++ )
    {
        cin >> array1[i] ;
    }
    cin >> number2 ; 
    int array2[number2] ;
    for ( int i = 0 ; i < number2 ; i++ )
    {
        cin >> array2[i] ;
    }
    cin >> number3 ; 
    int array3[number3] ;
    for ( int i = 0 ; i < number3 ; i++ )
    {
        cin >> array3[i] ;
    }
    for ( int i = 0 ; i < number1 ; i++ )
    {
        counter = 0 ;
        for ( int j = 0 ; j < number2 ; j++ )
        {
            if ( array1[i] == array2[j] )
            {
                counter++ ;
            }
        }
        for ( int j = 0 ; j < number3 ; j++ )
        {
            if ( array1[i] == array3[j] )
            {
                counter++ ;
            }
        }
        if ( counter == 2 )
        {
            numberofanswers++ ;
            cout << array1[i] << ' ' ;
        }
    }
    if ( numberofanswers == 0 )
    cout << "Nothing" ;
    return 0 ;
}