#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;
int main() {
    int k,n;
    cin >> k >> n;
    int nums[n];
    for(int i=0;i<k;i++){
        cin >> nums[i];
    }
    for(int i=0;i<n-k;i++){
        int minRot = 1;
        for(int j=0;j<k;j++){
            for(int u=0;u<k;u++){
                if(minRot == nums[i+u]){
                    minRot++;
                }
            }
        }
        nums[k+i] = minRot;
    }
    cout << nums[n-1];
}
