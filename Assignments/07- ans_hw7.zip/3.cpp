#include <iostream>
#include <iomanip>
using namespace std;
int main(){
	int s;
	cin >> s;
	int matrix[50][50];
	for(int i=0 ; i<s ; i++)
		for(int j=0 ; j<s ; j++)
			cin >> matrix[i][j] ;
	bool paeen_mosallasi = true , bala_mosallasi = true;
	for(int i=0 ; i<s ;i++){
		for(int j=0 ; j<s ;j++){
			if (i > j && matrix[i][j] != 0)
				bala_mosallasi = false;			
			if (i < j && matrix[i][j] != 0)
				paeen_mosallasi = false;
		}
	}
	if(paeen_mosallasi == true)
		cout << "Payein Mosalasi" ;
	else if(bala_mosallasi == true) 
		cout << "Bala Mosalasi" ;
	else 
		cout << "-1" ;	
	return 0;
}