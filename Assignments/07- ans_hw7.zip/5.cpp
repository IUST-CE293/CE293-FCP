#include <iostream>
using namespace std;

void multiply(int** X, int** Y, int** Z, int n) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            Z[i][j] = 0;
            for (int k = 0; k < n; k++) {
                Z[i][j] += X[i][k] * Y[k][j];
            }
        }
    }
}
void print(int** m, int n) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            cout << m[i][j] << " ";
        }
        cout << endl;
    }
}

int main() {
    int n;
    cin >> n;
    int** X, ** Y, ** Z;
    X = new int* [n];
    Y = new int* [n];
    Z = new int* [n];
    for (int i = 0; i < n; i++) {
        X[i] = new int[n];
        Y[i] = new int[n];
        Z[i] = new int[n];
    }
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            cin >> X[i][j];
        }
    }
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            cin >> Y[i][j];
        }
    }
    multiply(X, Y, Z, n);
    print(Z, n);

    for (int i = 0;i < n;i++) {
        delete[] X[i];
        delete[] Y[i];
        delete[] Z[i];
    }
    delete[] X;
    delete[] Y;
    delete[] Z;
}
