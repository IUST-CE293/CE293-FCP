#include <iostream>
using namespace std ;

int main ()
{
    string weekday ;
    int number1 , number2 , number3 , array1[7] = { 0 , 0 , 0 , 0 , 0 , 0 , 0 } ;
    cin >> number1 ;
    for ( int i = 0 ; i < number1 ; i++ )
    {
        cin >> weekday ;
        if ( weekday == "shanbe" )
        array1[0] = 1 ;
        else if ( weekday == "1shanbe" )
        array1[1] = 1 ;
        else if ( weekday == "2shanbe" )
        array1[2] = 1 ;
        else if ( weekday == "3shanbe" )
        array1[3] = 1 ;
        else if ( weekday == "4shanbe" )
        array1[4] = 1 ;
        else if ( weekday == "5shanbe" )
        array1[5] = 1 ;
        else
        array1[6] = 1 ;
    }
    cin >> number2 ;
    for ( int i = 0 ; i < number2 ; i++ )
    {
        cin >> weekday ;
        if ( weekday == "shanbe" )
        array1[0] = 1 ;
        else if ( weekday == "1shanbe" )
        array1[1] = 1 ;
        else if ( weekday == "2shanbe" )
        array1[2] = 1 ;
        else if ( weekday == "3shanbe" )
        array1[3] = 1 ;
        else if ( weekday == "4shanbe" )
        array1[4] = 1 ;
        else if ( weekday == "5shanbe" )
        array1[5] = 1 ;
        else
        array1[6] = 1 ;
    } 
    cin >> number3 ;
    for ( int i = 0 ; i < number3 ; i++ )
    {
        cin >> weekday ;
        if ( weekday == "shanbe" )
        array1[0] = 1 ;
        else if ( weekday == "1shanbe" )
        array1[1] = 1 ;
        else if ( weekday == "2shanbe" )
        array1[2] = 1 ;
        else if ( weekday == "3shanbe" )
        array1[3] = 1 ;
        else if ( weekday == "4shanbe" )
        array1[4] = 1 ;
        else if ( weekday == "5shanbe" )
        array1[5] = 1 ;
        else
        array1[6] = 1 ;
    }
    int counter = 0 ;
    for ( int i = 0 ; i < 7 ; i++ )
    {
        if ( array1[i] == 0 )
        counter++ ; 
    }
    cout << counter ; 
    return 0 ; 
}