#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <regex>
#include <sstream>
using namespace std;

// Helper class to store pointer operation details
struct PointerOperation {
    unsigned long long currentAddr;
    int value;
    unsigned long long jumpAddr;
    bool canJump;
};

// Modified helper function to be more lenient with address parsing
unsigned long long parseAddress(const string& addr) {
    // Find the hex number after any text and 0x
    size_t pos = addr.find("0x");
    if (pos == string::npos) {
        // If no 0x prefix, treat the whole string as a pointer value
        return stoull(addr, nullptr, 16);
    }
    return stoull(addr.substr(pos + 2), nullptr, 16);
}

// Helper function to validate pointer movement with more flexibility
bool isValidPointerMovement(const vector<PointerOperation>& ops) {
    for (size_t i = 0; i < ops.size() - 1; i++) {
        if (!ops[i].canJump) return false;
        
        // Allow for platform-specific pointer arithmetic
        unsigned long long expectedAddr = ops[i].jumpAddr;
        unsigned long long nextAddr = ops[i + 1].currentAddr;
        
        // Compare addresses allowing for platform differences
        if (abs((long long)(expectedAddr - nextAddr)) > sizeof(int)) return false;
    }
    return true;
}

// Modified path validation to be more lenient with pointer arithmetic
bool isValidPath(const vector<int>& nums, const vector<PointerOperation>& ops) {
    int currentIndex = 0;
    for (const auto& op : ops) {
        if (currentIndex >= nums.size()) return false;
        if (nums[currentIndex] != op.value) return false;

        if (op.canJump) {
            // Calculate jump size more flexibly
            unsigned long long diff = op.jumpAddr - op.currentAddr;
            int jumpSize = (diff + sizeof(int) - 1) / sizeof(int); // Round up
            if (jumpSize > op.value + 1) return false; // Allow for end pointer case
            currentIndex += jumpSize;
        }
    }
    return currentIndex <= nums.size();
}

bool isValidPointerFormat(const string& line, PointerOperation& op) {
    // More lenient regex that allows for different pointer formats
    regex pointerPattern(R"(Current:\s*([0-9a-fA-F]+|\w+)\s*\(value:\s*(\d+)\)\s*->\s*(Jump to:\s*([0-9a-fA-F]+|\w+)|Cannot jump))");
    smatch matches;

    if (regex_match(line, matches, pointerPattern)) {
        string addr = matches[1].str();
        op.currentAddr = parseAddress(addr);
        op.value = stoi(matches[2].str());

        if (matches[3].str().find("Jump to:") != string::npos) {
            op.jumpAddr = parseAddress(matches[4].str());
            op.canJump = true;
        } else {
            op.canJump = false;
        }
        return true;
    }
    return false;
}

bool isValidAddressFormat(const string& line, unsigned long long& addr) {
    // More lenient regex that allows for different pointer formats
    regex addressPattern(R"((Initial|Final)\s*pointer:\s*([0-9a-fA-F]+|\w+))");
    smatch matches;

    if (regex_match(line, matches, addressPattern)) {
        addr = parseAddress(matches[2].str());
        return true;
    }
    return false;
}

int main(int argc, char const *argv[]) {
    if (argc != 4) {
        cerr << "Usage: " << argv[0] << " test_in test_out user_out" << endl;
        return 2;
    }

    ifstream test_in(argv[1]);
    ifstream test_out(argv[2]);
    ifstream user_out(argv[3]);

    if (!test_in || !test_out || !user_out) {
        cerr << "Error opening files" << endl;
        return 2;
    }

    // Read input array
    int n;
    test_in >> n;
    vector<int> nums(n);
    for (int i = 0; i < n; i++) {
        test_in >> nums[i];
    }

    // Read expected result
    string expected_result;
    test_out >> expected_result;

    // Parse and validate user output
    string line;
    bool found_initial = false;
    bool found_final = false;
    bool found_result = false;
    string user_result;

    unsigned long long initial_addr = 0;
    unsigned long long final_addr = 0;
    vector<PointerOperation> operations;

    while (getline(user_out, line)) {
        // Trim whitespace from line
        line.erase(0, line.find_first_not_of(" \t\n\r"));
        line.erase(line.find_last_not_of(" \t\n\r") + 1);
        
        if (line.empty()) continue;

        if (line == "true" || line == "false") {
            user_result = line;
            found_result = true;
            continue;
        }

        if (line.rfind("Initial pointer:", 0) == 0) {
            if (found_initial || !isValidAddressFormat(line, initial_addr)) return 1;
            found_initial = true;
            continue;
        }

        if (line.rfind("Final pointer:", 0) == 0) {
            if (!found_initial || !isValidAddressFormat(line, final_addr)) return 1;
            found_final = true;
            continue;
        }

        if (line.rfind("Current:", 0) == 0) {
            PointerOperation op;
            if (!found_initial || !isValidPointerFormat(line, op)) return 1;
            operations.push_back(op);
            continue;
        }

        // Any other line format is invalid
        return 1;
    }

    // Validate all required elements are present
    if (!found_initial || !found_final || !found_result) {
        return 1;
    }

    // Validate pointer operations
    if (!operations.empty()) {
        // Check if initial pointer matches first operation
        if (initial_addr != operations.front().currentAddr) return 1;

        // Check if final pointer is consistent
        if (operations.back().canJump) {
            if (final_addr != operations.back().jumpAddr) return 1;
        } else {
            if (final_addr != operations.back().currentAddr) return 1;
        }

        // Validate pointer movements
        if (!isValidPointerMovement(operations)) return 1;

        // Validate path against input array
        if (!isValidPath(nums, operations)) return 1;
    } else {
        // For single element case
        if (n != 1 || initial_addr != final_addr) return 1;
    }

    // Check if the final result matches expected
    return (user_result == expected_result) ? 0 : 1;
}