#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
    int x;
    cin >> x;

    int y = (x / 100) * 100 + ((x / 10) % 10) + (x % 10) * 10;

    cout << y;

    return 0;
}
