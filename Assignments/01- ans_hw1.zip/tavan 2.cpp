#include <iostream>
#include <iomanip>
#include <cmath>

using namespace std;

int main()
{
    int x;
    cin >> x;

    cout << (1 << ((int)(log2(x)) + 1));
    return 0;
}
