#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
    int x, y, n;
    int res;

    cin >> y >> x >> n;

    res = n + y - n % x - x * (n % x < y);

    cout << res;

    return 0;
}
