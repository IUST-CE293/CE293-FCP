#include <iostream>
using namespace std;

int main()
{
    int k;
    cin >> k;
    int n = k * (k + 1) / 2;
    cout << n;
    return 0;
}
