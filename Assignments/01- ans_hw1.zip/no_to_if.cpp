#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
    long m, n;
    long res;

    cin >> m >> n;

    res = abs(m % 2 - n % 2) * (m % n) + (1 - abs(m % 2 - n % 2)) * m * n;

    cout << res;

    return 0;
}
