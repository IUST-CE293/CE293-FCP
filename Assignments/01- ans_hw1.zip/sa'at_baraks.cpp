#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
    int hour, minute;

    cin >> hour >> minute;
    hour = (12 - hour) % 12;
    minute = (60 - minute) % 60;

    cout << setw(2) << setfill('0') << hour << ":"
         << setw(2) << setfill('0') << minute << endl;

    return 0;
}
