#include <iostream>

using namespace std;

class Complex{
	private:
		int x , y , z , k , sumx , sumy , abx , aby , crossx , crossy;
		
		
	public:
		Complex(int a , int b , int c , int d): x(a) , y(b) , z(c) , k(d){
		}
		int getsumx(){
			sumx = x + z;
			return sumx;
		}
		int getsumy(){
			sumy = y + k;
			return sumy;
		}
		int getabx(){
			abx = x - z;
			return abx;
		}
		int getaby(){
			aby = y - k;
			return aby;
		}
		int getcrossx(){
			crossx = (x * z) - (y * k);
			return crossx;
		}
		int getcrossy(){
			crossy = (x * k) + (y * z);
			return crossy;
		}
		
};







int main (){
	int a , b , c , d;
	cin >> a;
	cin >> b;
	cin >> c;
	cin >> d;
	Complex A(a , b , c , d);
	cout << A.getsumx() << " " << A.getsumy() << endl;
	cout << A.getabx() << " " << A.getaby() << endl;
	cout << A.getcrossx() << " " << A.getcrossy() << endl;
}