#include <iostream>
#include <iomanip>
using namespace std;

class Wallet
{
    private:
        int total;
        float saving;
    public:
        Wallet ( int t , float s ) : total( t ) , saving( s ) {}
        int account_balance ()
        {
            return total;
        }
        void add ( int money )
        {
            total += money;
            cout << money << " added!" << endl;
        }
        void save ( int money , float percentage )
        {
            saving += percentage * money;
            total += money - percentage * money;
            cout << fixed << setprecision(6) << percentage * money << " saved!" << endl;
        }
        void withdraw( int money )
        {
            if ( money > total )
            {
                cout << "low account balance" << endl;
            }
            else
            {
                total -= money;
                cout << money << " withdrawed successfully" << endl;
                if ( total < 50000 ) cout << "Your total money is " << total << " less than 50 000!" << endl;
            }
        }
};

int main()
{
    Wallet mywallet( 1000 , 0 );
    mywallet.add( 100 );
    cout << mywallet.account_balance() << endl;
    mywallet.save( 4000 , 0.1);
    mywallet.withdraw(6000);
    mywallet.withdraw(100);
    cout << mywallet.account_balance() << endl;

}