#include<iostream>
using namespace std;

class Rectangle{
		private:
			int tool;
			int arz;
		public:
			void vorodi(){
				cin>>tool>>arz;
			}
			void hesab(){
				
				cout<<tool*arz;
			}
	};
	
int main(){
	
	Rectangle ob1;
	ob1.vorodi();
	ob1.hesab();
	
	
	return 0;
}