#include <iostream>
#include <iomanip>
#include <cmath>

using namespace std;

//declaring a class which has 2 parameters, real and img, real representing the real part of a complex number img representing the imaginary part
class Complex{
public:
    double real;
    double img;


};

//a complex function that takes 2 numbers and saves them as the parameters of complex
Complex constructComplex(double x, double y){
    Complex c;
    c.real = x;
    c.img = y;
    return c;
}

//a function that takes a complex type as input and multiplies a - in the imaginary part of the complex number
Complex conjugate (Complex c){
    c.img = -(c.img);
    return c;
}

//a function that takes 2 complex numbers and adds them together
Complex add(Complex one, Complex two){
    Complex result;
    result.real = one.real + two.real;
    result.img = one.img + two.img;
    return result;
}

//a function that takes 2 complex numbers and subtracts one from the other
Complex sub(Complex one, Complex two){
    Complex result;
    result.real = one.real - two.real;
    result.img = one.img - two.img;
    return result;
}

//a function that takes 2 complex numbers and multiplies them together
Complex mul(Complex one, Complex two){
    Complex result;
    result.real = (one.real * two.real) - (one.img * two.img);
    result.img = (one.img * two.real) + (two.img * one.real);
    return result;
}

//a function that takes a complex type input and by calculating the degree and the radius returns the polar form of the number
Complex printPolarForm(Complex c){
    double r = sqrt(pow(c.real, 2) + pow(c.img, 2));
    double radian = atan2(c.img, c.real);
    double degree = (180*radian)/3.14;
    cout << r << "e^(i" << degree << ")";
}

int main() {
    cout << fixed << setprecision(2);
    double x1, x2, y1, y2;
    cin >> x1 >> y1 >> x2 >> y2;
    Complex c = constructComplex(x1, y1);
    Complex c2 = constructComplex(x2, y2);
    Complex c3 = conjugate(c);
    cout << c3.real << ' ' << c3.img << '\n';
    Complex c4 = add(c, c2);
    cout << c4.real << ' ' << c4.img << '\n';
    Complex c5 = sub(c, c2);
    cout << c5.real << ' ' << c5.img << '\n';
    Complex c6 = mul(c, c2);
    cout << c6.real << ' ' << c6.img << '\n';
    printPolarForm(c);
    return 0;
}