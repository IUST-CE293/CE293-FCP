#include <iostream>
#include <vector>
#include <fstream>
#include <sstream>
#include <algorithm>
using namespace std;

struct Book {
    int id;
    string name;
    string publisher;
    float price;
    string category;
};

vector<Book> books;

void loadBooksFromFile(const string &filename) {
    ifstream file(filename);
    if (!file.is_open()) return;

    string line, header;
    getline(file, header); // خواندن هدر فایل
    while (getline(file, line)) {
        stringstream ss(line);
        string idStr, name, publisher, priceStr, category;
        getline(ss, idStr, ',');
        getline(ss, name, ',');
        getline(ss, publisher, ',');
        getline(ss, priceStr, ',');
        getline(ss, category, ',');

        Book book;
        book.id = stoi(idStr);
        book.name = name;
        book.publisher = publisher;
        book.price = stof(priceStr);
        book.category = category;
        books.push_back(book);
    }
    file.close();
}

void saveBooksToFile(const string &filename) {
    ofstream file(filename);
    file << "id,name,publisher,price,category\n";
    for (const auto &book : books) {
        file << book.id << "," << book.name << "," << book.publisher << ","
             << book.price << "," << book.category << "\n";
    }
    file.close();
}

void addBook() {
    Book book;
    cout << "Enter book details (id name publisher price category): ";
    cin >> book.id >> book.name >> book.publisher >> book.price >> book.category;

    for (const auto &b : books) {
        if (b.id == book.id) {
            cout << "Error: Book with same id already exists.\n";
            return;
        }
    }
    books.push_back(book);
    cout << "Book added successfully.\n";
}

void changeBookPrice() {
    int id;
    float newPrice;
    cout << "Enter book id and new price: ";
    cin >> id >> newPrice;

    for (auto &book : books) {
        if (book.id == id) {
            book.price = newPrice;
            cout << "Price updated successfully.\n";
            return;
        }
    }
    cout << "Error: Book with given id does not exist.\n";
}

void searchByCategory() {
    string category;
    cout << "Enter category: ";
    cin >> category;

    transform(category.begin(), category.end(), category.begin(), ::tolower);
    bool found = false;
    for (const auto &book : books) {
        string bookCategory = book.category;
        transform(bookCategory.begin(), bookCategory.end(), bookCategory.begin(), ::tolower);
        if (bookCategory == category) {
            cout << "ID: " << book.id << ", Name: " << book.name << ", Publisher: " << book.publisher
                 << ", Price: " << book.price << ", Category: " << book.category << "\n";
            found = true;
        }
    }
    if (!found) {
        cout << "No books found in this category.\n";
    }
}

void deleteBook() {
    int id;
    cout << "Enter book id to delete: ";
    cin >> id;

    auto it = remove_if(books.begin(), books.end(), [id](const Book &book) { return book.id == id; });
    if (it != books.end()) {
        books.erase(it, books.end());
        cout << "Book deleted successfully.\n";
    } else {
        cout << "Error: Book with given id does not exist.\n";
    }
}

int main() {
    const string filename = "books.csv";
    loadBooksFromFile(filename);

    string command;
    while (true) {
        cout << "\nCommands: add, change, search, delete, exit\nEnter command: ";
        cin >> command;

        if (command == "add") {
            addBook();
        } else if (command == "change") {
            changeBookPrice();
        } else if (command == "search") {
            searchByCategory();
        } else if (command == "delete") {
            deleteBook();
        } else if (command == "exit") {
            saveBooksToFile(filename);
            break;
        } else {
            cout << "Invalid command.\n";
        }
    }

    return 0;
}
