#include "iostream"
#include <stdio.h>

using namespace std;

class stu {

    private:

	string id, phno;
	char name[200];
    public:

	stu() {

	    for(int i = 0; i < 200; i++) {
	
		char buff = fgetc(stdin);
		if(buff == '\n') {

		    name[i] = '\0';
		    break;
		}
		name[i] = buff;
	    }
	    cin >> id;
	    cin >> phno;
	}
	void printinfo() {

	    cout << "Student Name : "<< name << endl << "Student Phone Number : " << id << endl << "Student Zip code : " << phno;
	}
};

int main() {

    stu s;
    s.printinfo();
    return(0);
}