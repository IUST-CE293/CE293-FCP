#include <iostream>
using namespace std;

class Circle
{
	
	protected:
		float r;
		
	public:
		
		float getArea()
		{
			return 3.14* r * r;
		}
		
		Circle(float y)
		{
			r = y;
		}
		
		float getPerimeter()
		{
			return 2 * 3.14 * r;
		}
	
};

int main()
{
	float r;
	cin>>r;
	Circle cir(r);
	cout<<cir.getPerimeter()<<endl<<cir.getArea();
}