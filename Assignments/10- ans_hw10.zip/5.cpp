#include <iostream>
#include <iomanip>
using namespace std;

class slmt { //salamat
	public:
		float sen[999],ghad[999],vazn[999];
};

float avgage(slmt c, int n) {//miangin sen
	float majmoo = 0;
	for(int i = 0; i < n; i++) {//sum
		majmoo += c.sen[i];
	}
	float t = (majmoo/n) * 10;
	int f = t;
	return f / 10.0;
}

float avgweight(slmt c, int n){//miangin vazn
    float majmoo = 0;
    for(int i = 0; i < n; i++){//sum
        majmoo += c.vazn[i];
    }
    float t = (majmoo/n) * 10;
    int f = t;
    return f / 10.0;
}

float avgheight(slmt c, int n){//miangin ghad
    float majmoo = 0;
    for(int i = 0; i < n; i++){//sum
        majmoo += c.ghad[i];
    }
    float t = (majmoo/n) * 10;
    int f = t;

    return f / 10.0;

}

int main(){
	int c1,c2;
	slmt class1,class2;
	
	cin>>c1;
	
	for(int i = 0; i < c1; i++){
        cin >> class1.sen[i];
    }
    for(int i = 0; i < c1; i++){
        cin >> class1.ghad[i];
    }
    for(int i = 0; i < c1; i++){
        cin >> class1.vazn[i];
    }
    
    
    
    cin>>c2;
    
    for(int i = 0; i < c2; i++){
        cin >> class2.sen[i];
    }
    for(int i = 0; i < c2; i++){
        cin >> class2.ghad[i];
    }
    for(int i = 0; i < c2; i++){
        cin >> class2.vazn[i];
    }
    //////print mianginhaye 2 class
    cout << fixed << setprecision(1) << avgage(class1, c1) << endl << avgheight(class1, c1) << endl << avgweight(class1, c1) << endl;
    cout << fixed << setprecision(1) << avgage(class2, c2) << endl << avgheight(class2, c2) << endl << avgweight(class2, c2) << endl;
    
    if(avgheight(class1, c1) > avgheight(class2, c2)){
        cout << "A";
    }
	else if(avgheight(class1, c1) < avgheight(class2, c2)){
        cout << "B";
    }
    
    else if(avgweight(class2, c2) > avgweight(class1, c1)){
            cout << "A";
        }
    else if(avgweight(class2, c2) < avgweight(class1, c1)){
            cout << "B";
        }
    
    else if((avgheight(class1, c1) == avgheight(class2, c2)) && (avgweight(class2, c2) == avgweight(class1, c1))){
            cout << "Same";
        }
	
	
	
	
	
	
	
	
	
	
	
	
	
}