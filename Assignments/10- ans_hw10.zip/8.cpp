#include <iostream>
#include <string>
using namespace std; 
class Market
{
    string str[4];
    string name[100];
    int buying[100];
    int selling[100];
    int count[100];
    int profit = 0 ;
    int income = 0;
    int expense = 0;
    int i = 0 ;
    public :
    void Define(string* str)
    {
        name[i] = str[1];
        buying[i] = stoi(str[2]);
        selling[i] = stoi(str[3]);
        i++;

    }
    void Delete(string* str)
    {
        for(int j = 0; j < 100 ; j++)
        {
            if( name[j] == str[1])
            {
                if(count[j] == 0)
                {
                    name[j] = "";
                    buying[j] = 0 ; 
                    selling[j] = 0;
                    cout << "Deleted.";
                    break;

                }
                else 
                cout << '!' << endl;
            }
        }   
    }
    void Sell(string* str)
    {
         for(int j = 0; j < 100 ; j++)
        {
            if( name[j] == str[1])
            {
                if ( count[j] >= stoi(str[2]) )
                {
                    count[j] -= stoi(str[2]);
                    cout << stoi(str[2]) << name[j] << "sold!" << count[j] << "are left!";
                }
                else
                cout << "!" << endl;
            }
        }
    }
    void Buy(string* str)
    {
         for(int j = 0; j < 100 ; j++)
        {
            if( name[j] == str[1])
            {
                count[j] += stoi(str[2]);
                cout << stoi(str[2]) << "are bought! Now we have " << count[j] << name[j] << endl;
                break ;
            }
            else if( name[j] != str[1] && j==99)
            {
                for(int k =0; k < 100 ; k++)
                {
                    if( name[k]=="")
                    {
                        name[k] = str[1];
                        count[k] = stoi(str[2]);
                        cout << name[k] << " is added to the list!" << stoi(str[2]) << " items are bought!" << endl;
                        break;
                    }
                }
            }
            
        }
    }
    void Status(string* str)
    {
    
        for (int j=0; j < 100; j++)
        {
            if(!name[j].empty())
            cout << name[j] << ' ' << buying[j] << ' ' << selling[j] << ' ' << count[j] << endl;
        }   
    }
    void Financial(string* str)
    {
        income = 0;
        expense = 0;
        for( int j = 0; j < 100; j++)
        {
            if(!name[j].empty())
            income += (selling[j]) * count[j];
            expense += (buying[j]) * count[j];

        }
        profit = income - expense; 
        cout << "Incomes: " << income << " ,expenses: " << expense << " ,profit: " << profit << endl;

    }


};
int main ()
{
    string s[4];
    cout << "Please enter a command:";
    cin>>s[0];
    Market m;
    while(s[0]!="Exit")
    {
        if (s[0] == "Define")
        {
            cin>>s[1]>>s[2]>>s[3];
            m.Define(s);
        }
        else if (s[0] == "Delete")
        {
            cin>>s[1];
            m.Delete(s);
        }
        else if (s[0] == "Sell")
        {
            cin>>s[1]>>s[2];
            m.Sell(s);
        }
        else if (s[0] == "Buy")
        {
            cin>>s[1]>>s[2];
            m.Buy(s);
        }
        else if (s[0] == "Status")
        {
            m.Status(s);
        }
        else if (s[0] == "Financial")
        {
            m.Financial(s);
        }
        else
        {
            cout << "Error!" << endl;
        }
        for(int i = 0; i<4; i++)
        {
            s[i] = "";
        }
        cout << "Please enter a command:";
        cin>>s[0];

    }
    cout << "Goodbye!";

    return 0;
}