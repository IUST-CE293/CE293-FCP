#include <iostream>
#include <iomanip>
#include <cmath> 
using namespace std;


float babeli(float x) {
    if(x == 0){
        return 0;
    }
    float g = x / 2; 
    float temp;      

    do {
        temp = g;                            
        g = (g + (x / g)) / 2;            
    } while (abs(temp - g) > 0.0001);       

    return g; 
}

int main() {
    float x;
    cin >> x;

    if (x < 0) {
    } else {
        cout << fixed << setprecision(5) << babeli(x) << endl;
    }

    return 0;
}
