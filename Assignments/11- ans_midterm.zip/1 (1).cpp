#include <iostream>
using namespace std;

int count = 0;
unsigned long long number;
unsigned long long temp;

int func1(unsigned long long number, unsigned long long i){
    if(number <= 1){
        return 0;
    }
    while (number % i == 0){ 
        number /= i; // 30, 15 ...... 5
        count++; // 1, 2 ........ 1
    }
    if(count != 0){
        cout << i << ' ' << count << endl; // 2^2*3^1*
        count = 0;
    }
    return func1(number, i+1);// 15, 3
}
int main(){
    cin >> number;
    temp = number;
    unsigned long long i = 2;
    func1(number, i); // 60, 2
}