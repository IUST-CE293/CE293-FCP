#include <iostream>
using namespace std;

int sum = 0;
int funcA(unsigned long long number){
    if(number == 0)
    {
        cout << 0;
    }
    if(number>0 && number<=9){ // 123456789
        cout << number;
        return 0;
    }
    unsigned long long temp;
    temp = number;
    while (temp > 0)
    {
        sum += (temp%10); // 9, 8, 7, 6, 5, 4, 3, 2, 1 
        temp /= 10; // 12
    }
    number = sum;
    sum = 0;
    return funcA(number);
    
}

int main(){
    unsigned long long number;
    cin >> number;

    funcA(number);
}