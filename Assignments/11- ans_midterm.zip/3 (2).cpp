#include <iostream>
#include <cmath>
using namespace std;
int power = 0;
unsigned long long sum = 0;
unsigned long long kharej=-1;
unsigned long long baghi;
int func1(int number, int mabna){
    // 1234
    // 1234/2==>617,,,,r=0
    // 617/2==>308,,,,,r=1
    // 308/2==>154,,,,,r=0
    // 154/2==>77,,,,,,r=0
    // 77/2===>38,,,,,, r=1
    // 38/2===>19,,,,,, r=0
    // 19/2===>9,,,,,,, r=1
    // 9/2 ===> 4 ,,,,, r=1
    // 4/2 ===> 2 ,,,,,, r=0
    // 2/2 ====> 1,,,,,, r=0
    // 1/2 ====> 0(end),,,,,, r=1
    if(kharej == 0){
        cout << sum;
        return 0;
    }
    baghi = number % mabna;
    kharej = number / mabna;
    sum += (baghi) * pow(10, power);
    power++;
    return func1(kharej, mabna);
}

int main(){
    int number, mabna;
    cin >> number >> mabna;
    func1(number, mabna);
}