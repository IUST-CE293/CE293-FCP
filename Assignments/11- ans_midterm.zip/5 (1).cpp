#include <iostream>
using namespace std;

int a0, q, n;

unsigned long long summation = 0;
int sum(int a0, int q, int n){
    if(a0 == 0){
        cout << summation;
        return 0;
    }
    if(n <= 0){
        cout << summation;
        return 0;
    }
    summation += a0;
    a0 = q * a0;
    n--; // 1
    return sum(a0, q, n); // 6, 3, 1
}

int main(){
    // 2, 3, 2

    // 2, 6 ==> 8
    cin >> a0 >> q >> n;
    sum(a0, q, n);
}