#include <iostream>
#include <cmath>
#include <cstdlib> // برای rand()
#include <ctime>   // برای srand()

using namespace std;

double monteCarloPI(int n) {
    const int TOTAL_POINTS = 1000000; // تعداد نقاط در هر تکرار
    double precision = pow(10, -n);  // دقت بر اساس ورودی
    double previous_pi = 0.0;
    double current_pi = 0.0;
    int iterations = 0;

    srand(time(0)); // مقداردهی اولیه به تولیدکننده اعداد تصادفی

    while (true) {
        int inside_circle = 0;

        for (int i = 0; i < TOTAL_POINTS; ++i) {
            double x = static_cast<double>(rand()) / RAND_MAX; // مقدار x تصادفی بین 0 و 1
            double y = static_cast<double>(rand()) / RAND_MAX; // مقدار y تصادفی بین 0 و 1

            if (x * x + y * y <= 1) { // بررسی داخل ربع دایره بودن
                inside_circle++;
            }
        }

        // محاسبه مقدار تقریبی PI
        current_pi = 4.0 * inside_circle / TOTAL_POINTS;
        iterations++;

        // بررسی پایداری مقدار تقریبی
        if (fabs(current_pi - previous_pi) < precision) {
            break;
        }

        previous_pi = current_pi;
    }

    return round(current_pi * pow(10, n)) / pow(10, n); // گرد کردن به n رقم اعشار
}

int main() {
    int n;
    cin >> n;

    double approx_pi = monteCarloPI(n);
    cout << approx_pi << endl;

    return 0;
}
