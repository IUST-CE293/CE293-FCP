#include <iostream> 
using namespace std;

int main()
{
    long long matrix[2][2];
    int l = 0;int w = 0;
    for(int i=0;i<4;i++)
    {
        cin >> matrix[l][w];
        w++;
        if(w==2)
        {
            w=0;
            l++;
        }
    }
    cout << (long long)(matrix[0][0]*matrix[1][1]) - (long long)(matrix[1][0]*matrix[0][1]) << endl;
    return 0;
}