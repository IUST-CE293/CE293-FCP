#include <iostream>
#include <algorithm>
using namespace std;

int main()
{
    int l,w,h;
    cin >> l >> w >> h;
    int matrix[l][w][h];
    for(int i=0;i<l;i++)
        for(int j=0;j<w;j++)
            for(int k=0;k<h;k++)
                cin >> matrix[i][j][k];

    int x1,x2,y1,y2,z1,z2;
    cin >> x1 >> y1 >> z1 >> x2 >> y2 >> z2;

    int max_el = -1;
    for(int i = min(x1,x2);i<=max(x1,x2);i++)
        for(int j = min(y1,y2);j<=max(y1,y2);j++)
            for(int k = min(z1,z2);k<=max(z1,z2);k++)
                max_el = max(max_el,matrix[i][j][k]);
                
    cout << max_el << endl;
    return 0;
}