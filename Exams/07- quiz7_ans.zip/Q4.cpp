#include <iostream>
#include <vector>
using namespace std;

    int majorityElement(vector<int>& nums) {
        int n = nums.size();
        for(int i=0;i<n;i++)
        {
            for(int j=i+1;j<n;j++)
            {
                if(nums[j]>nums[i])
                {
                    int temp = nums[j];
                    nums[j]=nums[i];
                    nums[i]= temp;
                }
            }
        }
        vector<int> counts;
        vector<int> new_nums;
        int now = nums[0];
        int count = 0;
        for(int i=0;i<n;i++)
        {
            count++;
            if(i==n-1)
            {
                new_nums.push_back(now);
                counts.push_back(count);
                break;
            }
            if(nums[i+1]!=now )
            {
                new_nums.push_back(now);
                now = nums[i+1];
                counts.push_back(count);
                count = 0;
            }
        }
        int max_index = 0;
        int max = 0;
        for(int i = 0;i<counts.size();i++)
        {
            if(counts[i]>max)
            {
                max_index = i;
                max = counts[i];
            }
        }
        return new_nums[max_index];
    }

int main()
{
    int n,temp;
    cin >> n;
    vector<int> nums;
    while (n)
    {
        cin >> temp;
        nums.push_back(temp);
        n--;
    }
    cout << majorityElement(nums) << endl;
    return 0;
}