#include <iostream>
#include <vector>
using namespace std;

int main()
{
    int n;
    int m;
    cin >> n >> m;
    char chars[n];
    char s[m];
    for(int i=0;i<n+m;i++)
    {
        if(i<n)
            cin >> chars[i];
        else
            cin >> s[i-n];
    }
    vector<int> indexes;  
    for(int j=0;j<m;j++)
    {
        for(int i=0;i<n;i++)
        {
            if(chars[i]==s[j])
            {
                indexes.push_back(i);
                break;
            }
        }
    }
    if(indexes.size()!=m)
        cout << "Not Found";
    else
    {
        for(int i=0;i<m;i++)
            cout << indexes[i] << ' ';
    }
    cout << endl;
    return 0;
}