#include <iostream>
using namespace std;
int kmm (int n , int a , int b){
    if(n%a==0 && n%b==0)
    return n;
    else 
    return kmm(n+1 , a , b);
}
int main(){
    int a,b;
    cin>>a>>b;
    int n=max(a,b);
    cout<<kmm(n,a,b);
}