#include <iostream>
#include <cmath>
using namespace std;
bool isprime (long long int n){
    int counter=0;
    for(long long int i=1 ; i<=sqrt(n) ; i++){
    if(n%i==0){
        counter++;
    }}
    if(counter>1 || n==1)
    return false;
    else return true;
}
bool isjansakht (long long int n){
    if(n<10 && isprime(n))
    return true;
    else if(isprime(n)){
        n/=10;
        return isjansakht(n);
    }
    else return false;
}
int main(){
    int n;
    cin>>n;
    for(int i=pow(10,n-1) ; i<pow(10,n) ; i++){
        if(isjansakht(i)){
            cout<<i<<endl;
        }
    }
}