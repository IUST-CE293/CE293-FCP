#include <iostream>
using namespace std;

class date{
    int year,month,day;
    public:
    void set(){
        cin>>year>>month>>day;
    }
    void print(){
        if(day>9 && month>9) cout<< year<<"/"<<month<<"/"<<day;
        if(day<9 && month>9) cout<< year<<"/"<<month<<"/0"<<day;
        if(day>9 && month<9) cout<< year<<"/0"<<month<<"/"<<day;
        if(day<9 && month<9) cout<< year<<"/0"<<month<<"/0"<<day;
    }
    date(){
        set();
        print();
    }
    
};
int main(){
    date first;

}