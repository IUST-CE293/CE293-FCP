#include <iostream>
using namespace std;

class empl{
    private:
    string name;
    int id;
    float hours,paid;
    public:
    float actualpaid(){
        return hours*paid*0.9;
    }
    empl(){
        cin>>name>>id>>hours>>paid;
    }
    string getname(){

        return name;
    }

};

int main(){
    empl person1,person2;
    if(person1.actualpaid()>person2.actualpaid())cout<<person1.getname();
    else cout<< person2.getname();
}