#include <iostream>
using namespace std;

class rect{
    int height,width;
    public:
    void set(int h,int w){
        cin>>h>>w;
        height=h;
        width=w;
    }
    int area(){
        int a;
        a=height*width;
        return a;
    }
    bool is_square(){
        if(height==width) return true;
        else return false;
    }
    rect(){
        cin>>height>>width;
    }

};

int main(){
    int h,w;

    rect rectangle;
    rectangle.set(h,w);
    cout<<rectangle.area()<<endl<<rectangle.is_square();

}