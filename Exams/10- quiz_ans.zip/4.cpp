#include <iostream>
using namespace std;
class account{
    public:
    string name;
    int balance=0;
    void deposit(int h){
        if(h<=balance && h<0)balance=balance+h;
        
    }
    void withdraw(int s){
        if(s>0)balance=balance+s;
    }
    int check(){
        return balance;
    }
};
int main(){
    string temp;
    account person;
    int h=0,s=0;
    cout<< "if you want to deposit press d and if you want to withdraw press w if you want to check balance press c and if you want to quit press q"<<endl;
    while(true){
        cin>> temp;
        if(temp=="d") {
            cin>>h;
            if(h>person.check())cout<<"not enough"<<endl;
            person.deposit(h);
        }
        if(temp=="w") {
            cin>>s;
            person.withdraw(s);
        }
        if(temp=="c") {
            cout<<person.check()<<endl;
        }
        if(temp=="q") {
            cout<< "have a good day";
            break;
        }
        temp="";
        h=0;
        s=0;

    }
    
}