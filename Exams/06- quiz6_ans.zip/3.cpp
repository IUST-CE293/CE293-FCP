#include <iostream>
#include <string>

using namespace std;

int counter(int x , int group[] , int n){
    // این تابع تعداد تکرار عدد ایکس را در آرایه گروپ به طول ان نشان می دهد
    int count=0;
    for (int i = 0 ; i<n ; i++){
        if (group[i] == x){
            count ++ ;
        }
    }
    return count;
}

int main()
{

    int n;
    cin >> n;
    int group[n];
    for (int i = 0 ; i<n ; i++){
        cin >> group[i];
    }
    int one , two , three , four;
    one = counter(1 , group , n);
    two = counter(2 , group , n);
    three = counter(3 , group , n);
    four = counter(4 , group , n);

    int taxi = 0;

    int one_three;
    int two_two = two/2;
    int one_r = 0;
    int two_r = 0;
    int three_r = 0;

    if (one>three){
        one_three = three;
        one_r = one - three;
    }
    else if (one <= three){
        one_three = one;
        three_r = three - one;
    }
    if (two%2 == 1){
        two_r = 1;
    }

    int two_r_one_r = 0;
    if (one_r>0 && two_r == 1){
        two_r_one_r = 1;
        one_r -= 2;
        two_r -= 1;
    }

    taxi = four + one_three + two_two + two_r_one_r + three_r + two_r + one_r/4;
    if (one_r%4>0){
        taxi++;
    }

    cout << taxi;
    return 0;
}