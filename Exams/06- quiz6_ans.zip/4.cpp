#include<iostream>
#include<string>

using namespace std;

int main(){
    int n; cin >> n;
    int num1[n];
    for (int i =n-1 ; i>=0 ; i--){
        cin >> num1[i];
    }
    int num2[n];
    for (int i =n-1 ; i>=0 ; i--){
        cin >> num2[i];
    }

    int result[n+1];
    for (int i =0 ; i<=n ; i++){
        result[i] = 0;
    }
    for (int i =0 ; i<=n ; i++){
        if (num1[i] + num2[i] < 10){
            result[i] += num1[i] + num2[i];
            if (result[i] >= 10){
                result[i] = result[i] % 10;
                result[i+1] ++ ;
            }
        }
        else if (num1[i] + num2[i] >= 10){
            result [i] += (num1[i] + num2[i]) % 10;
            result [i+1] ++;
        }         
    }
    for (int i =n-1 ; i>=0 ; i--){
        cout << result[i];
    }

    return 0;
}