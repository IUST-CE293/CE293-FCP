#include<iostream>
#include<string>

using namespace std;

int main(){
    long long int n ; cin >> n;
    long long int price[n];
    for (long long int i=0 ; i<n ; i++){
        cin >> price[i];
    }
    long long int sood = 0;
    for (long long int i=0 ; i<n-1 ; i++){
        if (price[i+1] > price [i]){
            sood += price[i+1] - price[i];
        }
    }
    cout << sood;


    return 0;
}