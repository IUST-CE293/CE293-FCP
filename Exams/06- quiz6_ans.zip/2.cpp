#include<iostream>
#include<string>

using namespace std;

bool rep_check(int x , int i , int w[]){
    // این تابع چک می کند که آیا عدد ایکس در درایه آی اولین بار ظاهر می شود یا قبلا تکرار شده بوده در صورت تکرار شدن یک و در غیر این صورت صفر برگردانده میشود
    bool tekrar = false;
    for (int d=0 ; d<i ; d++){
        if (w[d] == x){
            tekrar = true;
        }
    }
    return tekrar;
}

int counter(int w , int a[] , int n){
// این تابع دنبال تعداد تکرار های عدد دبلیو در آرایه آ به طول ان می گردد و تعداد تکرار را بر می گرداند
    int count = 0;
    for (int i = 0 ; i<n ; i++){
        if (a[i] == w){
            count++;
        }
    }
    return count;
}

int tower_counter(int w[] , int n){
//این تابع تعداد درایه های متمایز آرایه دبلیو به اندازه ان را برمیگرداند

    int count = 0;
    for (int i = 0 ; i<n ; i++){
        if (rep_check(w[i] , i , w) == false)
        {
            count ++;
        }
        
    }
    return count;
}

int main(){

    int n; cin >> n;
    int w[n];
    for (int i =0 ; i<n ; i++){
        cin >> w[i];
    } 
    int counters[n];
    for (int i = 0 ; i<n ; i++){
        counters[i] = counter(w[i] , w , n);
    }

    for (int j=0 ; j<n ; j++){
        for (int i = 0 ; i<n-1 ; i++){
            if (counters[i] < counters[i+1]){
                int temp = counters[i];
                counters[i] = counters[i+1];
                counters[i+1] = temp;
            }

        }
    }

    cout << counters[0] << " " << tower_counter(w , n) ;
    return 0;
}