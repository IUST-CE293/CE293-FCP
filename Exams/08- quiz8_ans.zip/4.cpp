#include<iostream>
using namespace std;

int main()
{
    string input;
    int n;
    cin >> input >> n;
    char* letters = new char[input.length()];
    for ( int i = 0 ; i < input.length() ; i++ )
    {
        *( letters + i ) = input[i];
    }
    for ( int i = n + 1 ; i < input.length() ; i++ )
    {
        cout << *( letters + i );
    }
    for ( int i = 0 ; i < n + 1 ; i++ )
    {
        cout << *( letters + i );
    }
    delete letters;
    return 0;
}