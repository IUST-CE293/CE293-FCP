#include <iostream>
using namespace std;
int main(){
    string S,subS;
    int counter=0,Counter=0;
    getline(cin,S);
    getline(cin,subS);
    int lengthS=S.length(),lengthsubS=subS.length();
    char S1[S.length()],subS1[subS.length()];
    for(int i=0 ; i<lengthS ; i++){
        S1[i]=S[i];
    }
    for(int i=0 ; i<lengthsubS ; i++){
        subS1[i]=subS[i];
    }
    for(int i=0 ; i<lengthS ; i++){
        for(int j=0 ; j<lengthsubS ; j++){
            if(*(S1+i+j)==*(subS1+j))
            counter++;
        }
        if(counter==lengthsubS)
        Counter++;
        counter=0;
    }
    if(Counter>0)
    cout<<"The substring is found "<<Counter<<" times.";
    else 
    cout<<"The substring is not found.";
}
