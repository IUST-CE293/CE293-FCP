#include <iostream>
#include <iomanip>
using namespace std;
void fact(int *a){
  int i=0;
  cout<<"Factorial of array is: ";
  while(a[i]!=-1000){
    int zarb=1;
    for(int j=1;j<=a[i];j++)
      zarb*=j;
    cout<<zarb<<' ';
    i++;
  }
  cout<<endl;
  
}
void miangin(int *a){
  int i=0;
  double jam=0;
  cout<<"The average of the array is: ";
  while(a[i]!=-1000){
      jam+=a[i];
      i++;
  }
  cout << fixed << setprecision(2) << jam/i << endl;
}
void bubbleSort(int *a) {
    for (int i = 0; i <99; i++) {
        for (int j = 0; j < 99-i; j++) {
            if (a[j] > a[j + 1]) {
                int temp = a[j];
                a[j] = a[j + 1];
                a[j + 1] = temp;
            }
        }
    }
}

int main() 
{
    int a[100];
    for(int i=0;i<100;i++)
      a[i]=-1000;
    int n,i=0;
    while(cin>>n){
      a[i]=n;
      i++;
    }
      fact(a);
      miangin(a);
      bubbleSort(a);
      cout<<"Sorted array: ";
      for(int d=0;d<100;d++){
        if(a[d]!=-1000)
          cout<<a[d]<<' ';
      }
            cout<<endl<<"Reversed array: ";
      for(int d=99;d>=0;d--){
        if(a[d]!=-1000)
          cout<<a[d]<<' ';
      }
      
    return 0;
}