#include <iostream>
using namespace std;

void a1(int* c, int s, int i, int a) 
{
    int c1 = *(c+i);
    for (int l =i;l<i+a && l<s-1;l++) 
    {
        *(c+l) = *(c+l+1);
    }
    if (i+a<s) 
    {
        *(c+i+a)=c1;
    }
}

void a2(int* c, int s, int i, int a)
 {
    int c1 = *(c+i);
    for (int l=i;l>i-a && l>0;l--) 
    {
        *(c+l) = *(c+l-1);
    }
    if (i-a>=0) 
    {
        *(c+i-a)=c1;
    }
}

int main() 
{
    int c[10];
    int n,m,s,h;

   
    for (int i=0;i<10;i++)
    {
        cin>>*(c + i);
    }
    cin>>n;


    for (int i=0;i<n;i++) 
    {
        cin>>m>>s;
        m--; 
    
        if (s>0)
        {
            a1(c,10,m,s);
        } else 
        {
            a2(c,10,m,-s);
        }
    }

  
    cin>>h;

    
    for (int i=0;i<10;i++) 
    {
        cout <<*(c + i) << " ";
    }
    cout << endl;

    
    if (*c == h) {
        cout << "you win!";
    } else {
        cout << "you lose!";
    }
    return 0;
}
