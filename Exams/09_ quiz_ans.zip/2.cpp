#include <iostream>
#include <vector>
#include <string>
using namespace std;

struct fly {
    int fly_number;
    string togo;
    int number;
    int rezerv;
};

void rezervi(vector<fly>& flights, const string& togo, int seats) {
    for (auto& flight : flights) {
        if (flight.togo == togo) {
            if (flight.number - flight.rezerv >= seats) {
                flight.rezerv += seats;
                cout << seats << " seats booked for " << togo << ". Remaining: " << (flight.number - flight.rezerv) << endl;
            } else {
                cout << "Flight to " << togo << " not enough seats available." << endl;
            }
            return;
        }
    }
}

void ticketout(vector<fly>& flights, const string& togo, int seats) {
    for (auto& flight : flights) {
        if (flight.togo == togo) {
            if (flight.rezerv >= seats) {
                flight.rezerv -= seats;
                cout << seats << " seats canceled for " << togo << ". Remaining: " << (flight.number - flight.rezerv) << endl;
            } else {
                cout << "Only " << flight.rezerv << " seats can be canceled for " << togo << "." << endl;
            }
            return;
        }
    }
}

int main() {
    int n;
    cin >> n;
    vector<fly> flights(n);

    for (int i = 0; i < n; i++) {
        cin >> flights[i].fly_number >> flights[i].togo >> flights[i].number;
        flights[i].rezerv = 0;
    }

    int m;
    cin >> m;

    for (int i = 0; i < m; i++) {
        string togo, operation;
        int seats;
        cin >> togo >> operation >> seats;

        if (operation == "book") {
            rezervi(flights, togo, seats);
        } else if (operation == "cancel") {
            ticketout(flights, togo, seats);
        }
    }

    return 0;
}
