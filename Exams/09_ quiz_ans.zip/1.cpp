#include <iostream>
#include <string>

using namespace std;


struct Book 
{
    int id;
    string name;
    string subject;
    int stock;
};


void s(const Book books[], int n, const string& p) {
    bool found = false;

    for (int i = 0; i < n; ++i) {
        if (books[i].stock > 0) { 
           
            if (to_string(books[i].id) == p) 
            {
                cout << "ID: " << books[i].id << ", Name: " << books[i].name << ", Subject: " << books[i].subject<< ", Stock: " << books[i].stock << endl;
                found = true;
            }
            
            else if (books[i].subject == p)
             {
                cout << "ID: " << books[i].id << ", Name: " << books[i].name << ", Subject: " << books[i].subject << ", Stock: " << books[i].stock << endl;
                found = true;
            }
            
            else if (books[i].name.find(p) != string::npos) 
            {
                cout << "ID: " << books[i].id<< ", Name: " << books[i].name<< ", Subject: " << books[i].subject<< ", Stock: " << books[i].stock << endl;
                found = true;
            }
        }
    }

    if (!found)
     {
        cout << "not found" << endl;
    }
}

int main() {
    int n;
    cin >> n; 
    Book books[50]; 

    for (int i = 0; i < n; ++i)
    {
        cin >> books[i].id >> books[i].name >> books[i].subject >> books[i].stock;
    }

    string p;
    cin >> p; 

    s(books, n, p);

    return 0;
}