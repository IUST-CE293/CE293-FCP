#include <iostream>
using namespace std;

int main()
{
    string s1 , s2;
    cin >> s1 >> s2;
    bool yes = true;
    for ( int i = 0 ; i < s1.length() ; i++ )
    {
        for ( int j = 0 ; j < s2.length() ; j++ )
        {
            if ( s1[i] == s2[j] )
            {
                s1[i] = ',';
                s2[j] = ',';
            }
        }
    }
    for ( int i = 0 ; i < s1.length() ; i++ )
    {
        if ( s1[i] != ',' )  yes = false;
    }
    if ( !yes ) cout << "no";
    else        cout << "yes";

}
