#include <iostream>
#include <string>
#include <vector>
using namespace std;

int m(string str, string& rm) {
    int n = str.size();
    vector<vector<int>> dp(n, vector<int>(n, 0));

    for (int len = 2; len <= n; ++len) {
        for (int i = 0; i <= n - len; ++i) {
            int j = i + len - 1;
            if (str[i] == str[j]) dp[i][j] = dp[i + 1][j - 1];
            else                   dp[i][j] = 1 + min(dp[i + 1][j], dp[i][j - 1]);
        }
    }

    int i = 0, j = n - 1;
    rm = "";
    string lrm = "", rrm = "";

    while (i <= j) {
        if (str[i] == str[j]) 
        {
            i++;
            j--;
        } 
        else if (dp[i + 1][j] <= dp[i][j - 1]) 
        {
            lrm += str[i];
            i++;
        } 
        else 
        {
            rrm = str[j] + rrm;
            j--;
        }
    }

    rm = lrm + rrm;
    return dp[0][n - 1];
}

int main() {
    string input;
    cin >> input;

    string rm;
    int rms = m(input, rm);

    cout << rms << endl;
    if (rms > 0) {
        cout << rm << endl;
    }

    return 0;
}
