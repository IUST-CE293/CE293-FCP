#include <iostream>
#include <cmath>
using namespace std;

// example1:::
// 0 0 == a1 b1
// 0 10 == a2 b2
// 10 0 == a3 b3
// 1 1 == x y
// a1,b1,a2,b2 ==> M
// a1,b1,a3,b3 ==> N
// a3,b3,a2,b2 ==> P
// perimeter2 = M + N + P = (2 + sqrt(2))*5 = 10 + 5*sqrt(2)

int main()
{
    double a1, a2, a3, b1, b2, b3; // مختصات رئوس مثلث رو با این اسامی نامگذاری کردیم
    double x, y; // نقطه ای که قرار است محل آن بررسی شود

    cin >> a1 >> b1;
    cin >> a2 >> b2;
    cin >> a3 >> b3;
    cin >> x >> y;


    double M, N, P; // اندازه اضلاع مثلث اصلی ساخته شده
    M = sqrt(pow((a1 - a2), 2) + pow((b1 - b2), 2));
    N = sqrt(pow((a1 - a3), 2) + pow((b1 - b3), 2));
    P = sqrt(pow((a2 - a3), 2) + pow((b2 - b3), 2));
    double perimeter2; // محیط تقسیم بر 2
    perimeter2 = (M + N + P) / 2;
    double area;
    area = sqrt((perimeter2-M) * (perimeter2 - N) * (perimeter2 - P)*(perimeter2));
    
    //از اینجا به پایین کپی پیست هستش 
    // مثلث اول
    // x,y,a1,b1,a2,b2
    // a1 , a2 رو گرقتیم طول رئوس قاعده مثلث == M قاعده است
    M = sqrt(pow((a1 - a2), 2) + pow((b1 - b2), 2));
    double P2, N2;
    N2 = sqrt(pow((a1 - x), 2) + pow((b1 - y), 2));
    P2 = sqrt(pow((a2 - x), 2) + pow((b2 - y), 2));
    double p_t_1; // محیط اولین مثلث
    p_t_1 = (M + N2 + P2)/2;
    double area2;
    area2 = sqrt((p_t_1-M) * (p_t_1 - N2) * (p_t_1 - P2)*(p_t_1));


    // مثلث دوم
    // x,y,a1,b1,a3,b3
    // a1 , a2 رو گرقتیم طول رئوس قاعده مثلث === M ضلع چپی است
    M = sqrt(pow((a1 - a3), 2) + pow((b1 - b3), 2));
    N2 = sqrt(pow((a1 - x), 2) + pow((b1 - y), 2));
    P2 = sqrt(pow((a3 - x), 2) + pow((b3 - y), 2));
    double p_t_2; // محیط دومین مثلث
    p_t_2 = (M + N2 + P2)/2;
    double area3;
    area3 = sqrt((p_t_2-M) * (p_t_2 - N2) * (p_t_2 - P2)*(p_t_2));

    // مثلث سوم
    // x,y,a2,b2,a3,b3
    // a1 , a2 رو گرقتیم طول رئوس قاعده مثلث == M ضلع راستی است
    M = sqrt(pow((a2 - a3), 2) + pow((b2 - b3), 2));
    N2 = sqrt(pow((a2 - x), 2) + pow((b2 - y), 2));
    P2 = sqrt(pow((a3 - x), 2) + pow((b3 - y), 2));
    double p_t_3; // محیط سومین مثلث
    p_t_3 = (M + N2 + P2)/2;
    double area4;
    area4 = sqrt((p_t_3-M) * (p_t_3 - N2) * (p_t_3 - P2)*(p_t_3));

    if (area2 == 0 || area3 == 0 || area4 == 0)
    {
        cout << "on" << endl;
    }
    else
    {
        // اگر این فلور هارو نزنید، تست کیس 1 پاس نمیشه و نمره اش به همه داده شد
        // چون فلور تدریس نشده بود و سر کلاس هم گفته نشد.
        area = floor(area);
        area2 = floor(area2);
        area3 = floor(area3);
        area4 = floor(area4);

        if (area == (area2 + area3 + area4))
        {
            cout << "in" << endl;
        }

        else if (area < (area2 + area3 + area4))
        {
            cout << "out" << endl;
        }

        else
        {
            cout << "on" << endl;
        }
    }

}