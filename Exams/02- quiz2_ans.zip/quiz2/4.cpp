#include<iostream>
using namespace std;

int main()
{
    long m , n , a;
    long length , width;
    cin >> m >> n >> a;

    if (m % a == 0)
    {
        length = m / a;
    }
    
        
    else 
    {
        length = (m / a) + 1;
    }
        

    if (n % a == 0)
    {
        width  = (n / a);
    }
        
    else 
    {
        width  = (n / a) + 1;
    }
        

    if ((length * width ) == 0)
    {
        length = 1 , width  = 1;
    }
        
        
    cout << length * width ;


}