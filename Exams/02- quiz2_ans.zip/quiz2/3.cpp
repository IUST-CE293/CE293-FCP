#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
    char cORr;
    double x,y;
    double r;
    double PI = 3.14159;
    cin >> cORr;

    if (cORr == 'r')
    {
        cin >> x >> y;
        cout << fixed << setprecision(3) << x * y << endl;
    }
    else if (cORr == 'c')
    {
        cin >> r;
        cout << fixed << setprecision(5) << PI * r * r << endl;
    }
}