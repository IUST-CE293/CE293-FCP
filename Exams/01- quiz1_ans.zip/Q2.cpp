#include <iostream>
using namespace std;

int main()
{
    double a,b,c;
    cin >> a >> b >> c;
    cout << (b*b - (2*a*c)) / (a*a) << endl;
    return 0;
}
