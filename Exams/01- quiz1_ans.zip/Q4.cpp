#include <iostream>
using namespace std;
 
int main()
{
    int a,b,c,d;
    cin >> a >> b >> c >> d;
    d = d*((d>0)-(d<0));
    int exp_1 = (a%2!=0)&&(c%2!=0)&&((b*b*b)%3==0);
    int exp_2 = (a%6==4)||(b%6==4);
    int exp_3 = ((a*b)+c>d);
    cout << (exp_1 || exp_2 || exp_3) << endl;
    return 0;
}