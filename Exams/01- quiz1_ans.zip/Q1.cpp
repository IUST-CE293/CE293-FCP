#include <iostream>
using namespace std;

int main()
{
    int n;
    cin >> n;
    int ans = -15+(n*(n+1))/2;
    cout << ans << endl;
    return 0;
}