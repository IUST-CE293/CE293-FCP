#include <iostream>
using namespace std;

int main()
{
    int x,y;
    cin >> x >> y;
    int ans = (x>y)*(x%y) + (y>x)*(y/x) + (x==y)*(x*x*x);
    cout << ans << endl;
    return 0;
}