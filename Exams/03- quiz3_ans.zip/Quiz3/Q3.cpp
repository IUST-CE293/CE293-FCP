#include <iostream>
using namespace std;

int main() {
    int n;
    cin >> n;

    int currentRow = 1, count = 0;

    for (int i = 1; i <= n * (n + 1) / 2; i++) { 
        cout << currentRow << " ";
        count++;

        if (count == currentRow) {
            cout << endl; 
            currentRow++;
            count = 0; 
        }
    }

    return 0;
}
