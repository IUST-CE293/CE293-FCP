#include <iostream>
using namespace std;

int main() {
    int base1, base2;
    cin >> base1 >> base2;

    int number;
    cin >> number; 

    int decimalValue = 0;
    int power = 1;

 
    while (number > 0) {
        int digit = number % 10; 
        decimalValue += digit * power;
        power *= base1;
        number /= 10;
    }

    int result = 0;
    int multiplier = 1;

    while (decimalValue > 0) {
        int remainder = decimalValue % base2;
        result += remainder * multiplier;
        decimalValue /= base2;
        multiplier *= 10;
    }

    cout << result << endl; 

    return 0;
}
