#include <iostream>
using namespace std;

int main() {
    int n;
    cin >> n;

    int evenDigitSum = 0, oddDigitSum = 0;

    for (int i = n; i >= 1; --i) {
        int digitSum = 0;
        if (i >= 10) {
            digitSum += i / 10; 
            digitSum += i % 10; 
        } else {
            digitSum += i; 
        }

        if (i % 2 == 0) {
            evenDigitSum += digitSum;
        } else {
            oddDigitSum += digitSum;
        }
    }

    cout << "Sum of digits of even numbers: " << evenDigitSum << endl;
    cout << "Sum of digits of odd numbers: " << oddDigitSum << endl;

    return 0;
}
