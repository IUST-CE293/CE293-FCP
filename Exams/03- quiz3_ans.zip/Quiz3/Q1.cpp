#include <iostream>
using namespace std;

int main() {
    int n, sum = 0;
    cin >> n;

    cout << "Sum: ";
    bool first = true;
    for (int i = 10; i <= n; i++) {
        int tens = i / 10;      
        int units = i % 10;     
        if (tens == units) {    
            sum += i;
            if (!first) {
                cout << " + ";
            }
            cout << i;
            first = false;
        }
    }

    cout << " = " << sum << endl;
    return 0;
}
